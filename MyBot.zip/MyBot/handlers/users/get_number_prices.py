from aiogram import types
from keyboards.default.buttons import ortga_to_main
from aiogram.types import InlineKeyboardMarkup,InlineKeyboardButton,CallbackQuery
from aiogram.dispatcher import FSMContext
from loader import dp,bot,balance,price, sched
from uuid import uuid4
from keyboards.default.buttons import buttons
from data.config import fivesimnettoken as token
from utils.get_number import get_price,get_phone,get_sms,get_country,finish_order,get__country
from loader import soldnumbers


@dp.callback_query_handler(state="*",text='soldnumbers')
async def GoAdminPanelf(call: CallbackQuery, state: FSMContext):
    await state.finish()
    await call.message.delete()
    key = InlineKeyboardMarkup(row_width=3)
    if int(soldnumbers.count_users(user_id=call.from_user.id) // 5) == soldnumbers.count_users(call.from_user.id) / 5:
        users_count = soldnumbers.count_users(user_id=call.from_user.id) // 5
    else:
        users_count = soldnumbers.count_users(user_id=call.from_user.id) // 5 + 1
    all_users = soldnumbers.get_numbers(user_id=call.from_user.id)
    all_users.reverse()
    for i in range(0,5):
        try:
            data = soldnumbers.get_number(all_users[i])[0]
            data_1 = data[2].split(":")
            status = data_1.pop(3)
            if status == "active":
                emoji = "🟢"
            else:
                emoji = "🔴"
            key.add(InlineKeyboardButton(f"{emoji} {all_users[i]}", callback_data=f"number:{all_users[i]}"))
        except Exception as err:pass
    if users_count > 1:
        next_ = 2
    else:
        next_ = "no"
    if users_count == 0:
        users_count = 1
    key.add(InlineKeyboardButton("⬅️ Назад",callback_data=f"psold:no"))
    key.insert(InlineKeyboardButton(f"1/{users_count}",callback_data=f"page_count"))
    key.insert(InlineKeyboardButton("➡️ Вперед",callback_data=f"nsold:{next_}"))

    key.add(InlineKeyboardButton("↩️ Вернуться в меню",callback_data=f"back_main"))
    await bot.copy_message(chat_id=call.message.chat.id, from_chat_id="-1002045584833", message_id="10", caption="""
            ☎️ Ваши купленные номера!\n
            """, reply_markup=key)


@dp.callback_query_handler(state="*", text_contains ='nsold:')
async def GoAdminPanelf(call: CallbackQuery, state: FSMContext):
    await state.finish()
    next_ = call.data.replace("nsold:","")
    if next_ == "no":
        await call.answer("➡️ Не могу двигаться вперед")
        return
    await call.message.delete()
    current = int(next_)
    key = InlineKeyboardMarkup(row_width=3)
    if int(soldnumbers.count_users(call.from_user.id) // 5) == soldnumbers.count_users(call.from_user.id) / 5:
        users_count = soldnumbers.count_users(call.from_user.id) // 5
    else:
        users_count = soldnumbers.count_users(call.from_user.id) // 5 + 1 

    all_users = soldnumbers.get_numbers(user_id=call.from_user.id)
    all_users.reverse()


    for i in range(int(next_) * 5 - 5,int(next_) * 5):
        try:
            data = soldnumbers.get_number(all_users[i])[0]
            data_1 = data[2].split(":")
            status = data_1.pop(3)
            if status == "active":emoji="🟢"
            else:emoji="🔴"
            key.add(InlineKeyboardButton(f"{emoji} {all_users[i]}",callback_data=f"number:{all_users[i]}"))
        except:pass
    if users_count <= int(current):
        next_ = "no"
    else:
        next_ = int(current) + 1
    if int(current-1) >= 1:
        previus_ = current - 1
    else: 
        previus_ = "no"
    key.add(InlineKeyboardButton("⬅️ Назад",callback_data=f"psold:{previus_}"))
    key.insert(InlineKeyboardButton(f"{current}/{users_count}",callback_data=f"page_count"))
    key.insert(InlineKeyboardButton("➡️ Вперед",callback_data=f"nsold:{next_}"))

    key.add(InlineKeyboardButton("↩️ Вернуться в меню",callback_data=f"back_main"))
    try:
        await bot.copy_message(chat_id=call.message.chat.id, from_chat_id="-1002045584833", message_id="10", caption="""
                    ☎️ Ваши купленные номера!\n
                    """, reply_markup=key)
    except:
        pass

@dp.callback_query_handler(state="*", text_contains ='psold:')
async def GoAdminPanelf(call: CallbackQuery, state: FSMContext):
    await state.finish()
    previus_ = call.data.replace("psold:","")

    if previus_ == "no":
        await call.answer("⬅️ Не могу двигаться назад")
        return
    await call.message.delete()
    current = int(previus_)
    key = InlineKeyboardMarkup(row_width=3)
    if int(soldnumbers.count_users(call.from_user.id) // 5) == soldnumbers.count_users(call.from_user.id) / 5:
        users_count = soldnumbers.count_users(call.from_user.id) // 5
    else:
        users_count = soldnumbers.count_users(call.from_user.id) // 5 + 1
    all_users = soldnumbers.get_numbers(user_id=call.from_user.id)
    all_users.reverse()
    for i in range(int(previus_) * 5 - 5,int(previus_) * 5):
        try:
            data = soldnumbers.get_number(all_users[i])[0]
            data_1 = data[2].split(":")
            status = data_1.pop(3)
            if status == "active":
                emoji = "🟢"
            else:
                emoji = "🔴"
            key.add(InlineKeyboardButton(f"{emoji} {all_users[i]}", callback_data=f"number:{all_users[i]}"))
        except:pass
    if users_count <= int(current):
        next_ = "no"
    else:
        next_ = current + 1
    if int(current-1) >= 1:
        previus_ = int(current) - 1

    else:
        previus_ = "no"
    key.add(InlineKeyboardButton("⬅️ Назад",callback_data=f"psold:{previus_}"))
    key.insert(InlineKeyboardButton(f"{current}/{users_count}",callback_data=f"page_count"))
    key.insert(InlineKeyboardButton("➡️ Вперед",callback_data=f"nsold:{next_}"))

    key.add(InlineKeyboardButton("↩️ Вернуться в меню",callback_data=f"back_main"))
    try:await bot.copy_message(chat_id=call.message.chat.id, from_chat_id="-1002045584833", message_id="10", caption="""
            ☎️ Ваши купленные номера!\n
            """, reply_markup=key)
    except:pass
@dp.callback_query_handler(state="*", text_contains ='number:')
async def GoAdminPanelf(call: CallbackQuery, state: FSMContext):
    await state.finish()
    user_id = call.data.replace("number:","")
    data =  soldnumbers.get_number(user_id)[0]
    data_1 = data[2].split(":")
    country = get__country(data_1.pop(0))
    product = data_1.pop(0)
    opearation_id = data_1.pop(0)
    status = data_1.pop(0)
    sms_code = data_1
    phone_number = data[3]
    number_price = price.get_price(f'{country}:{product}')
    if status == "active":
        sms_code_ = await get_sms(api_token=token, operation_id=opearation_id)
        if sms_code[-1] == "None":
            sc="❌ Не получено"
            count = 0
        else:
            count = len(sms_code)
            sc=sms_code[-1]
        if sms_code_ == "TimeOut":
            await call.message.delete()
            sms_codes = ""
            for sms_code in sms_code:
                sms_codes += f":{sms_code}"
            data = f"{country}:{product}:{opearation_id}:unactive{sms_codes}"
            soldnumbers.save_number(user_id=call.from_user.id, data=data, number=phone_number)
            btn = InlineKeyboardMarkup()
            btn.add(InlineKeyboardButton(text="💬Все полученные SMS", callback_data=f'db_allcode:{user_id}'))
            btn.add(InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data=f'back_main'))
            await call.message.answer(f"""
<b>📌Ваш купленный номер

🌐 Сервис: </b>{product.capitalize()} <b>
🔄 Страна: </b>{get__country(country).capitalize()} <b>
📊 Статус: </b>🔴 Устаревший <b>
💸 Сумма: </b>{number_price} ₽ <b>
📩 Последнee SMS: </b><code>{sc}</code><b>
📲 Номер телефона: </b><code>{phone_number}</code>

📨 Получено всегo <b>{count}</b> SMS 
        """, reply_markup=btn)
        else:
            sms_code = sms_code_
            number = sms_code.number
            product = sms_code.service
            country = sms_code.country
            time_left = int(sms_code.time_left)
            sms_code = sms_code.message
            minutes = time_left // 60
            seconds = time_left - minutes * 60
            if minutes < 10:
                time_min = "0" + str(minutes)
            else:
                time_min = minutes
            if seconds < 10:
                time_sec = "0" + str(seconds)
            else:
                time_sec = seconds
            buttons = InlineKeyboardMarkup(inline_keyboard=[
                [
                    InlineKeyboardButton('🔄 Обновить', callback_data=f"sms_phone_id:{opearation_id}:{number}:{number_price}"),

                ],
                [
                    InlineKeyboardButton('❌ Отменить заказ',
                                         callback_data=f"cancel_phone_id:{opearation_id}:{number}:{number_price}"),

                ],
                [

                    InlineKeyboardButton('💬Все полученные SMS', callback_data=f"all_code:{opearation_id}")
                ],
                [
                    InlineKeyboardButton('↩️ Вернуться в меню', callback_data=f"ortga_to_main")
                ]

            ])

            if sms_code:
                await call.message.delete()
                await call.message.answer(
                        f'<b>🌐 Cервис:</b> {product.capitalize()}\n<b>🔄 Cтрана:</b> {get__country(country).capitalize()}\n<b>📊 Статус: </b>🟢 Активный\n<b>📲 Hомер</b> - <code>{number}</code>\n<b>📩 Последнee SMS:</b> <code>{sms_code[-1]}</code>\n<b>⏳ Чтобы его активировать у вас есть:</b> {time_min}:{time_sec}\n\n📨 Получено всего <b>{len(sms_code)}</b> SMS',
                        reply_markup=buttons)
            else:
                await call.message.answer(
                    f'<b>🌐 Cервис:</b> {product.capitalize()}\n<b>🔄 Cтрана:</b> {get__country(country).capitalize()}\n<b>📊 Статус: </b>🟢 Активный\n<b>📲 Hомер</b> - <code>{number}</code>\n<b>📩 Последнee SMS:</b> <code>❌Ожидает SMS</code> \n<b>⏳ Чтобы его активировать у вас есть:</b> {time_min}:{time_sec}\n\n📨 Получено всего <b>0</b> SMS',
                    reply_markup=buttons)
                await call.message.delete()
            return
    else:
        await call.message.delete()
        btn = InlineKeyboardMarkup()
        btn.add(InlineKeyboardButton(text="💬Все полученные SMS", callback_data=f'db_allcode:{user_id}'))
        btn.add(InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data=f'back_main'))
        if sms_code[-1] == "None":
            sms_code="❌ Не получено"
            count = 0
        else:
            count = len(sms_code)
            sms_code=sms_code[-1]
        await call.message.answer(f"""
<b>📌Ваш купленный номер

🌐 Сервис: </b>{product.capitalize()} <b>
🔄 Страна: </b>{get__country(country).capitalize()} <b>
📊 Статус: </b>🔴 Устаревший <b>
💸 Сумма: </b>{number_price} ₽ <b>
📩 Последнee SMS:</b><code>{sms_code}</code><b>
📲 Номер: </b><code>{phone_number}</code>

📨 Получено всего <b>{count}</b> SMS 
    """, reply_markup=btn)

    
@dp.callback_query_handler(lambda c: c.data.startswith('country:'),state="*")
async def return_number(call: types.CallbackQuery,state: FSMContext):
    await state.finish()
    await call.message.delete()
    datas = call.data.split(':')
    country = datas[1]
    product = datas[2]
    number_price = price.get_price(f'{country}:{product}')
    user_balance = balance.get_balance(user_id=call.from_user.id)
    remain = await get_price(api_token=token,service_=product,country=get_country(country))
    get_number = InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton("💳 Oплатить",callback_data=f"pay:{country}:{product}"),
        InlineKeyboardButton("🔝 Пополнить баланс",callback_data="top_balance")

    ],
    [
        InlineKeyboardButton("↩️ Вернуться в меню", callback_data=f"back:{product}")
    ]
])
    product = product.capitalize()
    country = country.capitalize()
    if product == "Whatsapp":product="WhatsApp"
    elif product == "Tiktok":product="Tik Tok"
    if country == "Usa":country = "USA"
    await call.message.answer(f"""
<b>📌 Вы выбрали

🌐 Сервис:</b> {product}<b>
🔄 Страна:</b> {country}<b>
💸 Сумма:</b> {number_price} ₽<b>
⛔️ Oсталось:</b> {remain}<b>

💰 Баланс:</b> {round(float(user_balance)*100)/100} ₽
""",reply_markup=get_number)



async def warn_number(user_id,operation_id,phone_number,minutes,product,country,job_id):
    sched.remove_job(job_id=job_id)
    sms_code = await get_sms(api_token=token, operation_id=operation_id)
    if sms_code == "TimeOut":
        return
    keyboards = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="⬅️ Назад в номер", callback_data=f"number:{phone_number}")
        ],
        [
            InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")
        ]
    ])
    if sms_code.message:
        await bot.send_message(chat_id=user_id,text=f"""
<b>🌐 Cервис:</b> {product.capitalize()} 
<b>🔄 Cтрана:</b> {get__country(country).capitalize()}
<b>📊 Статус: </b>🟢 Активный
<b>📩 Последнee SMS: </b> <code>{sms_code.message[-1]}</code>
📨 Получено всего <b>{len(sms_code.message)}</b> SMS

🛍 Ваш заказ на номер <code>{phone_number}</code> находится в <b>{minutes}</b> минутах от истечения срока действия
🤞 Если вы не получили достаточно SMS, поторопитесь!
👉 Если вы потеряли сообщение о получении SMS. Пожалуйста, перейдите в раздел "📞 Купленные номера"!""",reply_markup=keyboards)
    else:
        await bot.send_message(chat_id=user_id,text=f"""
<b>🌐 Cервис:</b> {product.capitalize()} 
<b>🔄 Cтрана:</b> {get__country(country).capitalize()}
<b>📊 Статус: </b>🟢 Активный
<b>📩 Последнee SMS:</b> <code>❌Ожидает SMS</code>
📨 Получено всего <b>0</b> SMS

🛍 Ваш заказ на номер <code>{phone_number}</code> находится в <b>{minutes}</b> минутах от истечения срока действия
🤞 Bы ещё не получили SMS, поэтому поторопитесь!
👉 Если вы потеряли сообщение о получении SMS. Пожалуйста, перейдите в раздел "📞 Купленные номера"!""",reply_markup=keyboards)
    
async def expire_number(user_id,operation_id,phone_number,product,country,number_price,job_id):
    sched.remove_job(job_id=job_id)
    sms_code = await get_sms(api_token=token, operation_id=operation_id)
    if sms_code == "TimeOut":
        return
    keyboards = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="⬅️ Назад в номер", callback_data=f"number:{phone_number}")
        ],
        [
            InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")
        ]
    ])
    if sms_code.message:
        await finish_order(token,operation_id=operation_id)
        await bot.send_message(chat_id=user_id,text=f"""
<b>🌐 Cервис:</b> {product.capitalize()} 
<b>🔄 Cтрана:</b> {get__country(country).capitalize()}
<b>📊 Статус: </b> 🔴 Устаревший
<b>📩 Последнee SMS: </b> <code>{sms_code.message[-1]}</code>
📨 Получено всего <b>{len(sms_code.message)}</b> SMS

📱 Срок действия вашего заказа на номер <code>{phone_number} </code> истек
🎗 Остальные SMS вы можете найти в разделе "📞Kупленные номера" 
""",reply_markup=keyboards)
            
        sms_codes = ""
        for sms_code in sms_code.message:
            sms_codes += f":{sms_code}"
        data = f"{country}:{product}:{operation_id}:unactive{sms_codes}"
        soldnumbers.save_number(user_id=user_id, data=data,
                                    number=phone_number)
        text = f"""
<a href="tg://user?id={user_id}">👤 Пользователь </a> получил <b>{len(sms_code.message)}</b> SMS из номера
🆔 ID пользователя: <code>{user_id}</code>
📱 Teл. номер: <code>{phone_number}</code>
📩 Bходящих SMS:\n 
"""
        count = 0
        for sms_code_ in sms_code.message:
            count =+ 1 
            text+=f"┖{count}. Bходящий SMS: <code>{sms_code_}</code>"
        await bot.send_message(chat_id="-1002129445967",text=text)

    else:
        await finish_order(token,operation_id=operation_id)
        balance.update_balance(user_id=user_id, amount=float(number_price))
        await bot.send_message(chat_id=user_id,text=f"""
<b>🌐 Cервис:</b> {product.capitalize()} 
<b>🔄 Cтрана:</b> {get__country(country).capitalize()}
<b>📊 Статус: </b> 🔴 Устаревший
<b>📩 Последнee SMS:</b> <code>❌ Не получено</code>
📨 Получено всего <b>0</b> SMS

📱 Срок действия вашего заказа на номер <code>{phone_number}</code> истек
📩 Вам вернули денег, так как SMS на номер не был получен.
💸 Сумма денег, возвращенных на ваш счет, составляет <b>{number_price}</b> рубля
""",reply_markup=keyboards)
        soldnumbers.save_number(user_id=user_id, data=f"{country}:{product}:{operation_id}:unactive:None", number=phone_number)
        await bot.send_message(chat_id="-1002129445967",text = f"""
<a href="tg://user?id={user_id}">👤 Пользователь</a> получил <b>0</b> SMS из номера
🆔 ID пользователя: <code>{user_id}</code>
📱 Teл. номер: <code>{phone_number}</code>
📩 Bходящий SMS:\n  <code>❌ Не получено</code>
""")

    



@dp.callback_query_handler(lambda c: c.data.startswith('pay:'),state="*")
async def return_number(call: types.CallbackQuery, state: FSMContext):
    await state.finish()
    await call.message.delete()
    user_id = call.from_user.id
    datas = call.data.split(':')
    country = datas[1]
    product = datas[2]
    number_price = price.get_price(f'{country}:{product}')
    number_price = str(number_price).replace(",",".")
    user_balance = balance.get_balance(user_id=call.from_user.id)
    if float(user_balance)<float(number_price):
        await call.message.answer("❌ Недостаточно денег на балансе",reply_markup=ortga_to_main)
        return
    number = await get_phone(api_token=token,country=get_country(country),service=product)
    if number=="NoAvailableNumber":await call.message.answer("❌ На данный момент, для этой услуги нет готовых для получения SMS номеров, повторяйте попытки каждые 5 минут!🤝🏻",reply_markup=ortga_to_main);return
    elif number=="NotEnoughFunds":await call.message.answer("❌Произошла ошибка! Обратитесь к администратору @Ser4ikSupport , он решит эту проблему ✅",reply_markup=ortga_to_main);return
    sms_code = await get_sms(api_token=token, operation_id=number.operation_id)
    if sms_code.time_left > 901:
        minutes_1 = 30
        minutes_2 = 5
        seconds_1 = 1500
        seconds_2 = 299
    else: 
        minutes_1 = 15
        minutes_2 = 3
        seconds_1 = 720
        seconds_2 = 179 


    if number:
        buttons = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        '🔄 Обновить',
                        callback_data=f"sms_phone_id:{number.operation_id}:{number.number}:{number_price}",
                    ),
                ],
                [
                    InlineKeyboardButton(
                        '❌ Отменить заказ',
                        callback_data=f"cancel_phone_id:{number.operation_id}:{number.number}:{number_price}",
                    ),
                ],
                [
                    InlineKeyboardButton(
                        '💬Все полученные SMS',
                        callback_data=f"all_code:{number.operation_id}",
                    )
                ],
                [
                    InlineKeyboardButton(
                        '↩️ Вернуться в меню', callback_data="ortga_to_main"
                    )
                ],
            ]
        )

        balance.minus_balance(user_id=user_id,amount=float(number_price))
        await call.message.answer(f"<b>🌐 Cервис:</b> {product.capitalize()}\n<b>🔄 Cтрана:</b> {get__country(country).capitalize()}\n<b>📊 Статус: </b>🟢 Активный\n<b>📲 Hомер</b> - <code>{number.number}</code>\n<b>📩 Последнee SMS:</b> <code>❌Ожидает SMS</code> \n<b>⏳ Чтобы его активировать у вас есть:</b> {minutes_1}:00\n\n📨 Получено всего <b>0</b> SMS",reply_markup=buttons)
        soldnumbers.save_number(user_id=call.from_user.id, data=f"{country}:{product}:{number.operation_id}:active:None",
                                number=number.number)
        user_mention = call.from_user.get_mention()
        await bot.send_message("-1002129445967",f"""
🛍 Новый заказ в боте @Ser4ikShopBot!

<b>👌 Ник пользователя:</b> {user_mention}   
<b>📛 Имя пользователя:</b> @{call.message.chat.username}
<b>🆔 ID пользователя:</b> <code>{call.message.chat.id}</code>
<b>🌐 Сервис номерa:</b> {product}
<b>🔄 Страна номерa:</b> {country}
<b>💸 Сумма номерa:</b> {number_price} ₽

<b>💰 Баланс пользователя:</b> {round(float(user_balance)*100)/100} ₽
""")
        job_id1 = str(uuid4())
        job_id2 = str(uuid4())
        sched.add_job(warn_number,trigger="interval",seconds=seconds_1,id=job_id1,args=(user_id,number.operation_id,number.number,minutes_2,product,country,job_id1))
        sched.add_job(expire_number,trigger="interval",seconds=int(int(seconds_2)+int(seconds_1)),id=job_id2,args=(user_id,number.operation_id,number.number,product,country,number_price,job_id2))



    else:

        await call.message.answer('❌На данный момент такого номера не осталось.',reply_markup=ortga_to_main)
        
@dp.callback_query_handler(lambda c: c.data.startswith('sms_phone_id:'),state="*")
async def return_number(call: types.CallbackQuery, state: FSMContext):
    await state.finish()
    number = call.data.split(':')

    sms_code = await get_sms(api_token=token,operation_id=number[1])
    if sms_code == "TimeOut":
        await call.message.delete()
        await call.message.answer(
            ' 💥 Срок действия этого заказа уже истек. Закажите новый или получить последние пришедшие смс из раздела "📞Kупленные номера"',
            reply_markup=ortga_to_main)
        return
    product = sms_code.service
    country = sms_code.country
    time_left = int(sms_code.time_left)
    sms_code = sms_code.message
    minutes = time_left // 60 
    seconds = time_left - minutes * 60
    time_min = ""
    time_sec = ""
    if minutes < 10:time_min="0" + str(minutes)
    else:time_min = minutes
    if seconds < 10:time_sec="0" + str(seconds)
    else:time_sec = seconds



    buttons = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton('🔄 Обновить',callback_data=f"sms_phone_id:{number[1]}:{number[2]}:{number[3]}"),

        ],
        [
            InlineKeyboardButton('❌ Отменить заказ',callback_data=f"cancel_phone_id:{number[1]}:{number[2]}:{number[3]}"),

        ],
        [

            InlineKeyboardButton('💬Все полученные SMS',callback_data=f"all_code:{number[1]}")
        ],
        [
            InlineKeyboardButton('↩️ Вернуться в меню',callback_data=f"ortga_to_main")
        ]

    ])


    if sms_code:
        await call.message.delete()
        await call.message.answer(f'<b>🌐 Cервис:</b> {product.capitalize()}\n<b>🔄 Cтрана:</b> {get__country(country).capitalize()}\n<b>📊 Статус: </b>🟢 Активный\n<b>📲 Hомер</b> - <code>{number[2]}</code>\n<b>📩 Последнee SMS:</b> <code>{sms_code[-1]}</code>\n<b>⏳ Чтобы его активировать у вас есть:</b> {time_min}:{time_sec}\n\n📨 Получено всего <b>{len(sms_code)}</b> SMS',reply_markup=buttons)

    else:
        await call.message.delete()
        await call.message.answer(f'<b>🌐 Cервис:</b> {product.capitalize()}\n<b>🔄 Cтрана:</b> {get__country(country).capitalize()}\n<b>📊 Статус: </b>🟢 Активный\n<b>📲 Hомер</b> - <code>{number[2]}</code>\n<b>📩 Последнee SMS:</b> <code>❌Ожидает SMS</code> \n<b>⏳ Чтобы его активировать у вас есть:</b> {time_min}:{time_sec}\n\n📨 Получено всего <b>0</b> SMS',reply_markup=buttons)
        await call.answer("❌СМС-код еще не пришел!")

@dp.callback_query_handler(lambda c: c.data.startswith('cancel_phone_id:'),state="*")
async def return_number(call: types.CallbackQuery, state:FSMContext):
    await state.finish()
    user_id = call.from_user.id
    number = call.data.split(':')
    sms_code = await get_sms(api_token=token, operation_id=number[1])

    if sms_code == "TimeOut":
        await call.message.answer(
            ' 💥 Срок действия этого заказа уже истек. Закажите новый или получить последние пришедшие смс из раздела "📞Kупленные номера"',
            reply_markup=ortga_to_main)
        return
    time_left = int(sms_code.time_left)
    country = sms_code.country
    product = sms_code.service
    minutes = time_left // 60 
    seconds = time_left - minutes * 60
    time_min = ""
    time_sec = ""
    if minutes < 10:time_min="0" + str(minutes)
    else:time_min = minutes
    if seconds < 10:time_sec="0" + str(seconds)
    else:time_sec = seconds

    sms_code = sms_code.message

    buttons = InlineKeyboardMarkup(inline_keyboard=[
        [ 
            InlineKeyboardButton('🔄 Обновить',callback_data=f"sms_phone_id:{number[1]}:{number[2]}:{number[3]}"),

        ],
        [
            InlineKeyboardButton('❌ Отменить заказ',callback_data=f"cancel_phone_id:{number[1]}:{number[2]}:{number[3]}"),

        ],
        [

            InlineKeyboardButton('💬Все полученные SMS',callback_data=f"all_code:{number[1]}")
        ],
        [
            InlineKeyboardButton('↩️ Вернуться в меню',callback_data=f"ortga_to_main")
        ]

    ])

    
    
    if sms_code:
        await call.answer("❌ Этот заказ не предложит отмене! Потому что вы уже получили от него смс")
        await call.message.delete()
        await call.message.answer(
                    f'<b>🌐 Cервис:</b> {product.capitalize()}\n<b>🔄 Cтрана:</b> {get__country(country).capitalize()}\n<b>📊 Статус: </b>🟢 Активный\n<b>📲 Hомер</b> - <code>{number[2]}</code>\n<b>📩 Последнee SMS:</b> <code>{sms_code[-1]}</code>\n<b>⏳ Чтобы его активировать у вас есть:</b> {time_min}:{time_sec}\n\n📨 Получено всего <b>{len(sms_code)}</b> SMS',
                    reply_markup=buttons)
    else:
        result = await finish_order(token,operation_id=number[1])
        if result == "OK":
            await call.message.delete()
            await call.message.answer(f"✅Успешно! Вы отменили заказ и на ваш баланс вернули {number[3]} ₽!😄",reply_markup=ortga_to_main)
            soldnumbers.save_number(user_id=user_id, data=f"{country}:{product}:{number[1]}:unactive:None", number=number[2])
            balance.update_balance(user_id=user_id,amount=number[3])         
        elif result == "CantFinishError" or result == "TryAgainLater":
            await call.answer("""
❌Для того чтобы oтменить заказ, вы должны подождать 2 минуты, после этого, вы сможете oтменить заказ.
♻️Повторите попытку через некоторое время 😕""")
        elif result == "WrongOperationError":
            await call.message.delete()
            await call.message.answer("❌ Этот заказ не предложит отмене и теперь вы не можете получить смс-код (изза истека номера) с этим номером!",reply_markup=ortga_to_main)
@dp.callback_query_handler(state="*",text="back_main")
async def back_main_home(call:types.CallbackQuery, state: FSMContext):
    await state.finish()
    await call.message.delete()
    name = call.from_user.full_name
    user_id = call.from_user.id
    user_balance = balance.get_balance(user_id=user_id)

    await bot.copy_message(chat_id=call.message.chat.id, from_chat_id="-1002045584833", message_id="11", caption=f"""
<b>👤 Name:</b> <i>{name.replace(">",'').replace("<",'')}</i>
<b>💰 Balance:</b> {round(float(user_balance)*100)/100} ₽
<b>🆔 ID:</b> <code>{user_id}</code>

<i><b>ХОЧЕШЬ ПОПОЛНИТЬ БАЛАНС ОТ 5₽ ИЛИ ТЕБЕ НУЖНЫ СЕРВИСЫ, КОТОРЫХ НЕТ В БОТЕ? ПИШИ - @ser4iksupport ♥️</b></i>""", reply_markup=buttons)

@dp.callback_query_handler(lambda c: c.data.startswith('all_code:'),state="*")
async def return_number(call: types.CallbackQuery, state:FSMContext):
    await state.finish()
    operation_id = call.data.replace("all_code:","")
    sms_code = await get_sms(api_token=token, operation_id=operation_id)
    phone_number = sms_code.number
    if sms_code == "TimeOut":
        await call.message.delete()
        await call.message.answer(
        ' 💥 Срок действия этого заказа уже истек. Закажите новый или получить последние пришедшие смс из раздела "📞Kупленные номера"',
        reply_markup=ortga_to_main)
        return

    sms_code = sms_code.message
    all_text = "<b>📩 Все полученные вами SMS:</b>"
    count = 0
    if not(sms_code):
        await call.answer("❌SMS на этот номер еще не пришло")
        return
    await call.message.delete()
    backwardkey = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🔄 Обновить", callback_data=f"upditate:{operation_id}")
        ],
        [
        InlineKeyboardButton(text="⬅️ Назад в номер", callback_data=f"number:{phone_number}")
        ],
        [
            InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")
        ]
    ])
    for sms in sms_code:
        count += 1
        all_text += f'\n             <b>{count}.📥SMS-код:</b> <code>{sms}</code>'
    all_text += f'\n\n\n👉 Если вы потеряли сообщение о получении SMS. Пожалуйста, перейдите в раздел "📞 Купленные номера"!'
    await call.message.answer(all_text,reply_markup=backwardkey)

@dp.callback_query_handler(lambda c: c.data.startswith('upditate:'), state="*")
async def return_number(call: types.CallbackQuery, state: FSMContext):
    await state.finish()
    operation_id = call.data.replace("upditate:","")
    sms_code = await get_sms(api_token=token, operation_id=operation_id)
    phone_number = sms_code.number
    if sms_code == "TimeOut":
        await call.message.delete()
        await call.message.answer(
        ' 💥 Срок действия этого заказа уже истек. Закажите новый или получить последние пришедшие смс из раздела "📞Kупленные номера"',
        reply_markup=ortga_to_main)
        return

    sms_code = sms_code.message
    all_text = "<b>📩 Все полученные вами SMS:</b>"
    count = 0
    if not(sms_code):
        await call.answer("❌SMS на этот номер еще не пришло")
        return
    backwardkey = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="🔄 Обновить", callback_data=f"upditate:{operation_id}")
        ],
        [
        InlineKeyboardButton(text="⬅️ Назад в номер", callback_data=f"number:{phone_number}")
        ],
        [
            InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")
        ]
    ])
    for sms in sms_code:
        count += 1
        all_text += f'\n             <b>{count}.📥SMS:</b> <code>{sms}</code>'
    all_text += f'\n\n\n👉 Если вы потеряли сообщение о получении SMS. Пожалуйста, перейдите в раздел "📞 Купленные номера" !'
    try:
        await call.message.edit_text(all_text,reply_markup=backwardkey)
    except Exception:
        await call.answer("❌ Никаких изменений не обнаружено!")
@dp.callback_query_handler(lambda c: c.data.startswith('srefresh:'),state="*")
async def return_number(call: types.CallbackQuery,state:FSMContext):
    await state.finish()
    operation_id = call.data.replace("all_code:","")
    sms_code = await get_sms(api_token=token, operation_id=operation_id)
    phone_number = sms_code.number
    if sms_code == "TimeOut":
        await call.message.delete()
        await call.message.answer(
        ' 💥 Срок действия этого заказа уже истек. Закажите новый или получить последние пришедшие смс из раздела "📞Kупленные номера"',
        reply_markup=ortga_to_main)
        return

    sms_code = sms_code.message
    all_text = "<b>📩 Все полученные вами SMS:</b>"
    if not(sms_code):
        await call.answer("❌SMS на этот номер еще не пришло")
        return
    backwardkey = InlineKeyboardMarkup(inline_keyboard=[
        [
        InlineKeyboardButton(text="🔄 Обновить", callback_data=f"srefresh:{operation_id}")
        ],
        [
        InlineKeyboardButton(text="⬅️ Назад в номер", callback_data=f"number:{phone_number}")
        ],
        [
        InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")
        ]
    ])
    for count, sms in enumerate(sms_code, start=1):
        all_text += f'\n             <b>{count}.📥SMS:</b> <code>{sms}</code>'
    all_text += f'\n\n\n👉 Если вы потеряли сообщение о получении SMS. Пожалуйста, перейдите в раздел "📞 Купленные номера"!'
    try:
        await call.message.edit_text(all_text,reply_markup=backwardkey)
    except:
        await call.answer("❌ Никаких изменений не обнаружено!")



@dp.callback_query_handler(lambda c: c.data.startswith('db_allcode:'),state="*")
async def return_number(call: types.CallbackQuery,state:FSMContext):
    await state.finish()
    user_id = call.data.replace("db_allcode:","")
    data =  soldnumbers.get_number(user_id)[0]
    data_1 = data[2].split(":")
    country = get__country(data_1.pop(0))
    product = data_1.pop(0)
    opearation_id = data_1.pop(0)
    status = data_1.pop(0)
    sms_code = data_1
    phone_number = data[3]
    if sms_code[-1] == "None":
        await call.answer("❌ На этот номер телефона вообще не пришёл SMS")
        return 
    await call.message.delete()

    backwardkey = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(text="⬅️ Назад в номер", callback_data=f"number:{phone_number}")
        ],
        [
            InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")
        ]
    ])
    count = 0
    all_text = "<b>📩 Все полученные вами SMS:</b>"
    for sms in sms_code:
        count += 1
        all_text += f'\n             <b>{count}.📥SMS:</b> <code>{sms}</code>'
    all_text += f'\n\n\n<b>Обращайтесь😄 @ser4iksupport любые другие вопросы по SMS</b>'
    await call.message.answer(all_text,reply_markup=backwardkey)
   