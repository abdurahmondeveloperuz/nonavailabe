import sqlite3

from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandStart
from keyboards.default.buttons import buttons
from loader import dp, db, bot,balance, ref, ref_balance, ref_all_balance

from aiogram.dispatcher import FSMContext


@dp.callback_query_handler(state="*",text_contains="check_subs")
async def checked(call:types.CallbackQuery,state:FSMContext):
    await state.finish()
    user_id = call.from_user.id
    if ref.get_status(invited_user_id=user_id) == "notrewarded":
        invtr = ref.get_inviter(invited_user_id=user_id) 
        try:
            user = await bot.get_chat(invtr)
            referrer_mention = user.get_mention(as_html=True)
        except:
            pass 
        else:
            await call.message.answer(f'👥 Пользователь, {referrer_mention} пригласил вас в бот.')
            try:
                ref.set_status(invited_user_id=user_id, status="rewarded")
                mention = call.from_user.get_mention(as_html=True)
                await bot.send_message(chat_id=invtr,text=f"🎁 Ваш партнер, {mention} подписался на каналы, и на ваш счет был зачислен бонус 4 рублей")
                await bot.send_message(chat_id="-1001903119428",text=f"👥 {referrer_mention} пригласил {mention} и получил бонус")
                ref_balance.update_balance(user_id=invtr,amount=4)
                ref_all_balance.update_balance(user_id=invtr,amount=4)
            except:pass
    
    await call.message.answer("✅ Успешно! Для дальнейшей покупки номеров, нажмите /start")
@dp.message_handler(CommandStart(),state="*")
async def bot_start(message: types.Message,state:FSMContext):
    await state.finish()
    name = message.from_user.full_name
    user_id = message.from_user.id
    if ref.get_status(invited_user_id=user_id) == "notrewarded":
        invtr = ref.get_inviter(invited_user_id=user_id) 
        try:
            user  = await bot.get_chat(invtr)
            referrer_mention = user.get_mention(as_html=True)
        except Exception as e:
            pass
        else:
            await message.answer(f'👥 Пользователь, {referrer_mention} пригласил вас в бот.')
            try:
                ref.set_status(invited_user_id=user_id, status="rewarded")
                mention = message.from_user.get_mention(as_html=True)
                await bot.send_message(chat_id=invtr,text=f"🎁 Ваш партнер, {mention} подписался на каналы, и на ваш счет был зачислен бонус 4 рублей")
                await bot.send_message(chat_id="-1001903119428",text=f"👥 {referrer_mention} пригласил {mention} и получил бонус")
                ref_balance.update_balance(user_id=invtr,amount=4)
                ref_all_balance.update_balance(user_id=invtr,amount=4)
            except:pass


    try:
        user_get = await bot.get_chat(message.from_user.id)
        user_bio = user_get.bio    
        db.add_user(id=message.from_user.id,fullname=message.from_user.full_name,username=message.from_user.username)
        count = db.count_users()[0]
        await bot.send_message(chat_id='-1001903119428',text=f"""
🆕 Новый пользователь!
🆔 Идентификатор пользователя: {message.from_user.id}
📛 Пользователь: {message.from_user.get_mention()}
🌐 Имя пользователя: {message.from_user.username}
📍 Биография пользователя: {user_bio}
➖➖➖➖➖➖➖➖➖➖➖
🖐Итого: {count}""")
    except:pass
    user_balance = balance.get_balance(user_id=user_id)
    await bot.copy_message(chat_id=message.chat.id, from_chat_id="-1002045584833", message_id="11", caption=f"""
<b>👤 Name:</b> <i>{name.replace(">",'').replace("<",'')}</i>
<b>💰 Balance:</b> {round(float(user_balance)*100)/100} ₽
<b>🆔 ID:</b> <code>{user_id}</code>

<i><b>ХОЧЕШЬ ПОПОЛНИТЬ БАЛАНС ОТ 5₽ ИЛИ ТЕБЕ НУЖНЫ СЕРВИСЫ, КОТОРЫХ НЕТ В БОТЕ? ПИШИ - @ser4iksupport ♥️</b></i>""", reply_markup=buttons)