from aiogram import types
from aiogram.dispatcher.filters.builtin import CommandHelp

from loader import dp


@dp.message_handler()
async def bot_help(message: types.Message):
    await message.answer(
        "↪️<b> /start </b> - <i> Перезапуск бота.</i>\n<b>👨‍💻 /help </b>- <i>Tехподдержка.</i>")