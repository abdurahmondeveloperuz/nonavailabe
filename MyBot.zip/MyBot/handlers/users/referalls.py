from aiogram.utils.deep_linking import get_start_link, decode_payload
from aiogram.types import CallbackQuery,InlineKeyboardMarkup,InlineKeyboardButton, InlineQuery, InlineQueryResultArticle,InputTextMessageContent
from aiogram import types
from loader import dp,bot ,ref, ref_balance, ref_all_balance, balance
import sqlite3
from aiogram.dispatcher.filters.builtin import CommandStart
from keyboards.default.buttons import buttons, payout_key, back_main_home
from aiogram.dispatcher import FSMContext


async def create_link(id: int) -> str:
    return await get_start_link(id)

@dp.inline_handler()
async def referalls_query(query: InlineQuery):
    user_id = query.from_user.id
    link = await create_link(user_id)
    template1 = InlineQueryResultArticle(
        id=1,
        title="👥 Ваша реф. ссылка",
        thumb_url="https://telegra.ph/file/60621c9690c05fbb9c652.jpg",
        description="🔴Готовый текст + реф.ссылка",
        input_message_content=InputTextMessageContent(
            message_text=f"<b>Привет! Тут можно купить ЛУЧШИЕ виртуальные номера, ТОП 1 по конфиденциальности.\n🔗Моя реферальная ссылка: {link}</b> ",
        )
    )
    # "Привет! Тут можно купить ЛУЧШИЕ виртуальные номера, ТОП 1 по конфиденциальности.\n🔗Моя реферальная ссылка: "
    template2 = InlineQueryResultArticle(
        id=2,
        title="👥 Ваша реф. ссылка",
        thumb_url="https://telegra.ph/file/60621c9690c05fbb9c652.jpg",
        description="🟢Только реф.ссылка",
        input_message_content=InputTextMessageContent(
            message_text=f"{link}",
        )
    )
    results = [template1,template2]
    await bot.answer_inline_query(query.id, results=results, cache_time=5)

@dp.callback_query_handler(state="*",text="refsystem")
async def bot_stat(call: types.CallbackQuery,state:FSMContext):
    await call.message.delete()
    await state.finish()
    link = await create_link(call.from_user.id)
    keys = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton("💸 Вывод денег",callback_data="output_money")
        ],
        [
            InlineKeyboardButton(" 👥 Поделиться с друзьями",switch_inline_query=f"{call.from_user.id}")

        ],
        [
            InlineKeyboardButton("↩️ Вернуться в меню",callback_data="ortga_to_main")
        ]
    ])
    referalls_count = ref.get_ref_count(invitor_user_id=call.from_user.id)
    all_funds = round(float(ref_all_balance.get_balance(user_id=call.from_user.id))*100)/100
    remain_funds = round(float(ref_balance.get_balance(user_id=call.from_user.id))*100)/100
    all_verified = ref.get_rewarded(invitor_user_id=call.from_user.id)
    all_unverified = ref.get_notrewarded(invitor_user_id=call.from_user.id)
    await call.message.answer(f"""
🛍 В данном <a href='https://t.me/Ser4ikShopBot'>боте</a> присутствует реферальная система!

✉️ Ваша реферальная ссылка: <code>{link}</code>

💰 Вы будете получать 15% от всех пополнений ваших рефералов. 
💡 Легкий пример: если приглашёный Вами пользователь пополнит баланс на 100$, вы получите 15$.

💸 Вы будете получать 3% от пополнений рефералов ваших рефералов.
💡Легкий пример: если Ты пригласишь Ивана, а Иван пригласит Петра и Пëтр пополнит баланс, Ты получишь 3% от этого пополнения.

💵 А Также за каждого пользователя Вы будете получать 4₽ на реферальный счёт в <a href='https://t.me/Ser4ikShopBot'>боте</a> (для их получения пользователь должен: зайти в бота, нажать на /start и после этого, всего лишь нажать на кнопку подписаться! После этого Вам будет зачислено 4₽ и он официально будет вашим рефералом). ‼️ЭТО ПРОВЕРКА ЛЮДЕЙ НА БОТОВ‼️

👛 Минимальная сумма вывода на Ваш личный счет <b>в <a href='https://t.me/Ser4ikShopBot'>боте</a> от 1000₽</b>, а на <b>Вашу карту от 1200₽</b> - по любым вопросам , а также по вопросу с выводом денег, обращайтесь в техподдержку. - @Ser4ikSupport

🏆 Приглашено пользователей: {referalls_count} 
💰 Заработано всего: {all_funds} ₽ 
💳 Доступно на вывод: {remain_funds} ₽
🟢 Подписано на каналы: {all_verified}
🔴 Еще не подписано на каналы: {all_unverified}
""",reply_markup=keys, disable_web_page_preview=True)
    await call.answer(cache_time=30)
@dp.message_handler(state="*",commands=["referral"])
async def bot_stat(message: types.Message,state:FSMContext):
    await state.finish()
    user_id = message.from_user.id
    link = await create_link(user_id)
    keys = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton("💸 Вывод денег",callback_data="output_money")
        ],
        [
            InlineKeyboardButton(" 👥 Поделиться с друзьями",switch_inline_query=f"{user_id}")

        ],
        [
            InlineKeyboardButton("↩️ Вернуться в меню",callback_data="ortga_to_main")
        ]
    ])
    referalls_count = ref.get_ref_count(invitor_user_id=user_id)
    all_funds = round(float(ref_all_balance.get_balance(user_id=user_id))*100)/100
    remain_funds = round(float(ref_balance.get_balance(user_id=user_id))*100)/100
    all_verified = ref.get_rewarded(invitor_user_id=user_id)
    all_unverified = ref.get_notrewarded(invitor_user_id=user_id)
    await message.answer(f"""
🛍 В данном <a href='https://t.me/Ser4ikShopBot'>боте</a> присутствует реферальная система!

✉️ Ваша реферальная ссылка: <code>{link}</code>

💰 Вы будете получать 15% от всех пополнений ваших рефералов. 
💡 Легкий пример: если приглашёный Вами пользователь пополнит баланс на 100$, вы получите 15$.

💸 Вы будете получать 3% от пополнений рефералов ваших рефералов.
💡Легкий пример: если Ты пригласишь Ивана, а Иван пригласит Петра и Пëтр пополнит баланс, Ты получишь 3% от этого пополнения.

💵 А Также за каждого пользователя Вы будете получать 4₽ на реферальный счёт в <a href='https://t.me/Ser4ikShopBot'>боте</a> (для их получения пользователь должен: зайти в бота, нажать на /start и после этого, всего лишь нажать на кнопку подписаться! После этого Вам будет зачислено 4₽ и он официально будет вашим рефералом). ‼️ЭТО ПРОВЕРКА ЛЮДЕЙ НА БОТОВ‼️

👛 Минимальная сумма вывода на Ваш личный счет <b>в <a href='https://t.me/Ser4ikShopBot'>боте</a> от 1000₽</b>, а на <b>Вашу карту от 1200₽</b> - по любым вопросам , а также по вопросу с выводом денег, обращайтесь в техподдержку. - @Ser4ikSupport

🏆 Приглашено пользователей: {referalls_count} 
💰 Заработано всего: {all_funds} ₽ 
💳 Доступно на вывод: {remain_funds} ₽
🟢 Подписано на каналы: {all_verified}
🔴 Еще не подписано на каналы: {all_unverified}
""",reply_markup=keys, disable_web_page_preview=True)
@dp.callback_query_handler(state="*",text="output_money")
async def bot_stat(call: types.CallbackQuery,state:FSMContext):
    await call.message.delete()
    await state.finish()

    all_funds = round(float(ref_balance.get_balance(user_id=call.from_user.id))*100)/100
    await call.message.answer(f"""
💸 Вывести деньги с реферального баланса можно двумя способами:

🤖 <b>Первый способ</b>, с помощью бота - в этом случае минимальная сумма для вывода с реферального баланса составляет <b>1000</b> рублей.

💳 <b>Второй способ</b>, на Вашу карту. В этом случае минимальная сумма для вывода с реферального баланса составляет <b>1200</b> рублей.

💰 Bаш текущий реферальный баланс: {all_funds} ₽
🔻 Выберите нужный метод с помощью кнопок ниже!
""",reply_markup=payout_key)
    
@dp.callback_query_handler(state="*",text="payoutbot")
async def bot_stat(call: types.CallbackQuery,state:FSMContext):
    await state.finish()
    user_id = call.from_user.id
    user_balance = ref_balance.get_balance(user_id=user_id)
    if user_balance < 1000:
        await call.answer("❌ Минимальная сумма для снятия 1000 рублей.")
        return
    await call.message.delete()
    
    payoutbot = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(f"👉 Макс. {user_balance} ₽",callback_data=f"outputbotmax:{user_balance}")
        ],
        [
            InlineKeyboardButton("↩️ Вернуться в меню",callback_data="ortga_to_main")
        ]
    ])
    await call.message.answer("💰 Введите сумму от <b>1000 рублей</b>, которую Вы хотите вывести на баланс бота",reply_markup=payoutbot)
    await state.set_state("get_payout_amount")

@dp.message_handler(state="get_payout_amount")
async def bot_stat(message: types.Message,state:FSMContext):
    await state.finish()
    user_id = message.from_user.id
    user_balance = ref_balance.get_balance(user_id=user_id)
    user_main_balance = balance.get_balance(user_id=user_id)
    try:summa = float(message.text)
    except:
        await message.answer("😉 Пожалуйста, введите точное число для вывода:",reply_markup=back_main_home)
        await state.set_state("get_payout_amount")
        return
    else:
        if summa < 1000:
            await message.answer("❌ Минимальная сумма от 1000 рублей, введите сумму повторно:",reply_markup=back_main_home)
            await state.set_state("get_payout_amount")
            return
        if user_balance < float(message.text):
            await message.answer("➖ Не хватает баланс, введите сумму повторно:",reply_markup=back_main_home)
            await state.set_state("get_payout_amount")
            return
    
    buttons = InlineKeyboardMarkup()   
    buttons.add(InlineKeyboardButton('✅ Подтверждать',callback_data=f"output_verify:{summa}"))
    buttons.add(InlineKeyboardButton('❌ Oтменить',callback_data=f"output_ignore:"))
    await message.answer(f"""
🆕 Новая заявка на вывод
                                  
<b>🆔 Ваш ID:</b> <code>{user_id}</code>
<b>💰 Ваш основной баланс:</b> {round(float(user_main_balance) * 100) / 100}
<b>💸 Сумма вывода:</b> {message.text} ₽

<b>👥 Ваш реферальный баланс:</b> {user_balance}
""",reply_markup=buttons)
    
@dp.callback_query_handler(state="*",text_contains="outputbotmax:")
async def bot_stat(call: types.CallbackQuery,state:FSMContext):
    await call.message.delete()
    await state.finish()
    user_id = call.from_user.id
    r_balance = float(call.data.replace("outputbotmax:",""))
    user_balance = ref_balance.get_balance(user_id=user_id)
    user_main_balance = balance.get_balance(user_id=user_id)
    if user_balance < r_balance:
        await call.answer("❌ Устаревшее подтверждение. Попробуйте позже!")
        await call.message.delete()
        return 

    buttons = InlineKeyboardMarkup()   
    buttons.add(InlineKeyboardButton('✅ Подтвердить',callback_data=f"output_verify:{r_balance}"))
    buttons.add(InlineKeyboardButton('❌ Oтменить',callback_data=f"output_ignore:"))
    await call.message.answer(f"""
🆕 Новая заявка на вывод
                                  
<b>🆔 Ваш ID:</b> <code>{user_id}</code>
<b>💰 Ваш основной баланс:</b> {round(float(user_main_balance) * 100) / 100}
<b>💸 Сумма вывода:</b> {r_balance} ₽ 

<b>👥 Ваш реферальный баланс:</b> {user_balance}
""",reply_markup=buttons) 


@dp.callback_query_handler(state="*",text_contains="output_ignore:")
async def bot_stat(call: types.CallbackQuery,state:FSMContext):
    await state.finish()
    await call.message.edit_text(f"❌ Операция была отменена.",reply_markup=back_main_home)
@dp.callback_query_handler(state="*",text_contains="output_verify:")
async def bot_stat(call: types.CallbackQuery,state:FSMContext):
    await state.finish()
    user_id = call.from_user.id
    user_balance = float(call.data.replace("output_verify:",""))
    user_main_balance = balance.get_balance(user_id=user_id)
    r_balance = ref_balance.get_balance(user_id=user_id)
    await call.message.delete()
    if user_balance > r_balance:
        await call.answer("❌ Устаревшее подтверждение. Попробуйте позже!")
        await call.message.delete() 
    else:
        
        ref_balance.minus_balance(user_id=user_id,amount=user_balance)
        await call.message.answer(f"✅Успешно!😄Ваш запрос на вывод одобрен, и на ваш счет добавлено {float(user_balance)} ₽.",reply_markup=back_main_home)
        balance.update_balance(user_id=user_id,amount=user_balance)
        mention = call.from_user.get_mention(as_html=True)
        await bot.send_message(chat_id="-1002139212084",text=f"{mention} <b>Pеферальный баланс 🔄 Oсновной баланс</b>. Сумма: {user_balance}")





@dp.callback_query_handler(state="*",text="payoutcard")
async def bot_stat(call: types.CallbackQuery,state:FSMContext):
    await state.finish()
    user_id = call.from_user.id
    user_balance = ref_balance.get_balance(user_id=user_id)
    if user_balance < 1200:
        await call.answer("❌ Минимальная сумма для снятия 1200 рублей.")
        return
    await call.message.delete()
    
    payoutbot = InlineKeyboardMarkup(inline_keyboard=[
        [
            InlineKeyboardButton(f"👉 Макс. {user_balance} ₽",callback_data=f"payoutcardmax:{user_balance}")
        ],
        [
            InlineKeyboardButton("↩️ Вернуться в меню",callback_data="ortga_to_main")
        ]
    ])
    await call.message.answer("💰 Введите сумму от <b>1200 рублей</b>, которую Вы хотите вывести на карту.",reply_markup=payoutbot)
    await state.set_state("get_card_amount")
@dp.message_handler(state="get_card_amount")
async def bot_stat(message: types.Message,state:FSMContext):
    user_id = message.from_user.id
    user_balance = ref_balance.get_balance(user_id=user_id)
    user_main_balance = balance.get_balance(user_id=user_id)
    try:summa = float(message.text)
    except:
        await message.answer("😉 Пожалуйста, введите точное число для вывода:",reply_markup=back_main_home)
        await state.set_state("get_card_amount")
        return
    else:
        if summa < 1200:
            await message.answer("❌ Минимальная сумма от 1200 рублей, введите сумму повторно:",reply_markup=back_main_home)
            await state.set_state("get_card_amount")
            return
        if user_balance < float(message.text):
            await message.answer("➖ Не хватает баланс, введите сумму повторно:",reply_markup=back_main_home)
            await state.set_state("get_card_amount")
            return
    await state.set_data({f"{message.from_user.id}_amount":summa})
    await message.answer(f"""💳 Отправьте свою карту (Пример: <code>2202334318761005</code>):""",reply_markup=back_main_home)
    await state.set_state("get_card_number")
@dp.message_handler(state="get_card_number")
async def bot_stat(message: types.Message,state:FSMContext):
    if not(message.text.isdigit()):
        await message.answer("💳 Пожалуйста, введите действительные данные карты:",reply_markup=back_main_home)
        await state.set_state("get_card_number")
        return
    user_id = message.from_user.id
    user_balance = ref_balance.get_balance(user_id=user_id)
    user_main_balance = balance.get_balance(user_id=user_id)
    state_data = await state.get_data()
    await state.finish()
    summa = int(state_data.get(f"{user_id}_amount"))
    buttons = InlineKeyboardMarkup()   
    buttons.add(InlineKeyboardButton('✅ Подтвердить',callback_data=f"output_card_verify:{summa}:{message.text}"))
    buttons.add(InlineKeyboardButton('❌ Oтменить',callback_data=f"output_ignore:"))
    await message.answer(f"""
🆕 Новая заявка на вывод
                                  
<b>🆔 Ваш ID:</b> <code>{user_id}</code>
<b>💳 Вашa картa:</b> <code>{message.text}</code>
<b>💰 Ваш основной баланс:</b> {round(float(user_main_balance) * 100) / 100}
<b>💸 Сумма вывода:</b> {summa} ₽

<b>👥 Ваш реферальный баланс:</b> {user_balance}
""",reply_markup=buttons)


@dp.callback_query_handler(state="*",text_contains="payoutcardmax:")
async def bot_stat(call: types.CallbackQuery,state:FSMContext):
    await call.message.delete()
    await state.finish()
    user_id = call.from_user.id
    r_balance = float(call.data.replace("payoutcardmax:",""))
    user_balance = ref_balance.get_balance(user_id=user_id)
    if user_balance < r_balance:
        await call.answer("❌ Устаревшее подтверждение. Попробуйте позже!")
        await call.message.delete()
        return 
    await state.set_data({f"{user_id}_amount":r_balance})
    await call.message.answer(f"""💳 Отправьте свою карту (Пример: <code>2202334318761005</code>):""",reply_markup=back_main_home)
    await state.set_state("get_card_number")

@dp.callback_query_handler(state="*",text_contains="output_card_verify:")
async def bot_stat(call: types.CallbackQuery,state:FSMContext):
    await state.finish()
    user_id = call.from_user.id
    data = call.data.split(":")
    user_balance = float(data[1])
    card_number = data[2]
    user_main_balance = balance.get_balance(user_id=user_id)
    r_balance = ref_balance.get_balance(user_id=user_id)
    await call.message.delete()
    if user_balance > r_balance:
        await call.answer("❌ Устаревшее подтверждение. Попробуйте позже!")
        await call.message.delete() 
    else:
        pay = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(" ✅ Заплатил",callback_data=f"paid:{user_balance}:{card_number}:{user_id}")]])
        ref_balance.minus_balance(user_id=user_id,amount=user_balance)
        await call.message.answer(f"✅ Успешно! 😄Ваш запрос на вывод одобрен, и В течение <b>48 часов</b> заказ на вывод будет проверен  и оплачен нашими администраторами! {float(user_balance)} ₽.",reply_markup=back_main_home)
        mention = call.from_user.get_mention(as_html=True)
        await bot.send_message(chat_id="-1002139212084",text=f"""
🆕Новый заказ на вывод {mention} #NotPaid #Неоплачиваемый
       
<b>🆔 ID:</b> <code>{user_id}</code>
<b>💳 Kартa:</b> <code>{card_number}</code>
<b>💰 Oсновной баланс:</b> {round(float(user_main_balance) * 100) / 100}
<b>💸 Сумма вывода:</b> {user_balance} ₽

<b>👥 Реферальный баланс(до вывода):</b> {r_balance}""",reply_markup=pay)
@dp.callback_query_handler(state="*",text_contains="paid:")
async def bot_stat(call: types.CallbackQuery,state:FSMContext):
    await state.finish()
    data = call.data.split(":")
    user_id = data[3]
    credit_card = data[2]
    amount = data[1]
    await bot.send_message(chat_id=user_id,text=f"✅ Ваш запрос на вывод оплачено. Сумма - <b>{amount} ₽</b> , Карта - <code>{credit_card}</code>")
    text = call.message.text 
    text = text.replace("NotPaid","Paid")
    text = text.replace("Неоплачиваемый","Oплачиваемый")
    text = text.replace("🆕Новый заказ на вывод","✅ Оплаченный на вывод")
    skip=InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton(text="❌ Пропускать",callback_data="skip")]])
    await call.message.edit_text(text=text,reply_markup=skip)
@dp.callback_query_handler(state="*",text_contains="skip")
async def bot_stat(call: types.CallbackQuery,state:FSMContext):
    await state.finish()
    await call.answer("🔀 Пропущен")
    await call.message.delete()