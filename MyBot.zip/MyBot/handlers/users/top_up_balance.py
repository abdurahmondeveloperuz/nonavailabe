from aiogram import  types
from loader import dp, bot, paymentchecker, balance, ref, ref_balance, ref_all_balance
from aiogram.dispatcher import FSMContext
from keyboards.default.buttons import buttons,ortga_to_main, choice
from aiogram.types import InlineKeyboardMarkup,InlineKeyboardButton
from keyboards.default.buttons import buttons
from aiogram.types.web_app_info import WebAppInfo
from utils.misc.payments import new_aaio_payment, CryptoBot, XRocket, Payeer, check_aaio_payment

pay = CryptoBot(token="181068:AAC7DVAWra0I0VVqXuXKzhBSeDqUn7FIYie")
rocket = XRocket(token="b742d29479364b9f56c1bf3b7")
payeer = Payeer()

@dp.callback_query_handler(state="*",text="top_balance")
async def get_price(call:types.CallbackQuery,state:FSMContext):
    await state.finish()
    await call.answer(cache_time = 30)
    await call.message.delete()
    await bot.copy_message(chat_id=call.message.chat.id,from_chat_id="-1002045584833",message_id="9",caption="""
       ✉️ Уважаемые клиенты, если пополнение стоит от 100 рублей или Вы не знаете как пополнить баланс - напишите в @ser4iksupport , пополнение от 5 руб с комиссией ВСЕГО ЛИШЬ 1 рубль. Мы всегда рады Вам помочь🥰 
        """,reply_markup=choice)
@dp.callback_query_handler(state="*",text="xrocket_topup")
async def get_price(call:types.CallbackQuery,state:FSMContext):

    await state.finish()
    await call.answer(cache_time = 30)
    await call.message.delete()
    await bot.copy_message(chat_id=call.message.chat.id,from_chat_id="-1002045584833",message_id="9",caption="""
        🤔 На какую сумму вы хотите пополнить свой счет?(RUB)\n
        """,reply_markup=ortga_to_main)
    await state.set_state("amount_xrocket")

@dp.callback_query_handler(state="*",text="cryptobot_topup")
async def get_price(call:types.CallbackQuery,state:FSMContext):
    await state.finish()
    await call.answer(cache_time = 30)
    await call.message.delete()
    await bot.copy_message(chat_id=call.message.chat.id,from_chat_id="-1002045584833",message_id="9",caption="""
        🤔 На какую сумму вы хотите пополнить свой счет?(RUB)\n
        """,reply_markup=ortga_to_main)
    await state.set_state("amount_cryptobot")

@dp.callback_query_handler(state="*",text="payeer_topup")
async def get_price(call:types.CallbackQuery,state:FSMContext):
    await state.finish()
    await call.answer(cache_time = 30)
    await call.message.delete()
    await bot.copy_message(chat_id=call.message.chat.id,from_chat_id="-1002045584833",message_id="9",caption="""
        🤔 На какую сумму вы хотите пополнить свой счет?(RUB)\n
        """,reply_markup=ortga_to_main)
    await state.set_state("amount_payeer")

@dp.callback_query_handler(state="*",text="aaio_topup")
async def get_price(call:types.CallbackQuery,state:FSMContext):
    await state.finish()
    await call.answer(cache_time = 30)
    await call.message.delete()
    await bot.copy_message(chat_id=call.message.chat.id,from_chat_id="-1002045584833",message_id="9",caption="""
        🤔 На какую сумму вы хотите пополнить свой счет?(RUB)\n
        """,reply_markup=ortga_to_main)
    await state.set_state("amount_aaio")

@dp.message_handler(state="amount_xrocket")
async def get_price(message:types.Message,state:FSMContext):
    
    try:
        summa = float(message.text)
        summa  = round(float(summa) * 100) / 100 
    except:
        summa = False
    if summa: 
        if summa<10:
            await message.answer('➖ Минимальная сумма депозита 10 рублей.\n\n\n<i>Если вам нужно пополнить баланс на сумму, менее чем 10 рублей, oбращайтесь: @ser4iksupport😄</i>',reply_markup=ortga_to_main)
            await state.set_state('amount_xrocket')
            return
        await state.finish()
        pay_method = InlineKeyboardMarkup(inline_keyboard=[[InlineKeyboardButton("💎 TON", callback_data=f'pxrocket:ton:{summa}')],[InlineKeyboardButton("💎 NOT", callback_data=f'pxrocket:not:{summa}')],[InlineKeyboardButton("💎 USDT", callback_data=f'pxrocket:usd:{summa}')],[InlineKeyboardButton("↩️ Вернуться в меню", callback_data=f'ortga_to_main')]])
        await message.answer("💸 Выберите криптовалюту для оплаты", reply_markup=pay_method)
    else:
        back =  InlineKeyboardMarkup(
        inline_keyboard=[[
                InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="back_home")
            ]]
        )
        await message.answer("😉 Пожалуйста, введите точное число:",reply_markup=back)


@dp.callback_query_handler(text_contains="pxrocket:")
async def get_price(call:types.CallbackQuery,state:FSMContext):
    await call.message.delete()
    summa = call.data.split(":")[2]
    currency = call.data.split(":")[1]
    payment_details = rocket.create_invoice(amount=summa,currency=currency)
    bill_id = payment_details[1]
    URL = payment_details[0]
    paymentchecker.save_payment(
            bill_id=f"{bill_id}",
            amount=summa,
            user_id=call.from_user.id,
            status="active"
        )
    keyboard = InlineKeyboardMarkup()
    keyboard.add(InlineKeyboardButton('💳 Оплатить',url=URL))
    keyboard.add(InlineKeyboardButton('✅ Я oплатил',callback_data=f"payment_xrocket_id:{bill_id}"))
    keyboard.add(
            InlineKeyboardButton(
                '↩️ Вернуться в меню', callback_data="ortga_to_main_no_delete"
            )
        )

    await call.message.answer(f"""
Оплату можно произвести ниже, нажав кнопку: «Оплатить» или же нажав на: 
<a href='{URL}'>«Ссылка для оплаты»</a> 

Если вам нужно пополнить баланс на сумму, менее чем 10 рублей, а также, любые другие вопросы по платежу?
Обращайтесь😄: @ser4iksupport

💳 Cпособ оплаты: @TonRocketBot 


‼️ ВАЖНО: ЕСЛИ НА ВАШ СЧЕТ НЕ ПРИШЛИ ДЕНЬГИ, НАЖМИТЕ НА КНОПКУ "✅ Я оплатил".

""",disable_web_page_preview=True,reply_markup=keyboard)   


@dp.message_handler(state="amount_payeer")
async def get_price(message:types.Message,state:FSMContext):
    try:
        summa = float(message.text)
        summa  = round(float(summa) * 100) / 100 
    except:
        summa = False


    if summa: 
        if summa<50:
            await message.answer('➖ Минимальная сумма депозита 50 рублей.\n\n\n<i>Если вам нужно пополнить баланс на сумму, менее чем 10 рублей, oбращайтесь: @ser4iksupport😄</i>',reply_markup=ortga_to_main)
            await state.set_state('amount_payeer')
            return
        await state.finish()
        payment_details = await payeer.create_invoice(amount=summa)
        bill_id = payment_details[1]
        URL = payment_details[0]
        paymentchecker.save_payment(
            bill_id=f"{bill_id}",
            amount=message.text,
            user_id=message.from_user.id,
            status="active"
        )
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton('💳 Оплатить', url=URL))
        keyboard.add(InlineKeyboardButton('✅ Я oплатил',callback_data=f"payment_payeer_id:{bill_id}"))
        keyboard.add(
            InlineKeyboardButton(
                '↩️ Вернуться в меню', callback_data="ortga_to_main_no_delete"
            )
        )

        await message.answer(f"""
Оплату можно произвести ниже, нажав кнопку: «Оплатить» или же нажав на: 
<a href='{URL}'>«Ссылка для оплаты»</a> 

Если вам нужно пополнить баланс на сумму, менее чем 10 рублей, а также, любые другие вопросы по платежу?
Обращайтесь😄: @ser4iksupport

💳 Cпособ оплаты: Payeer 

‼️ ВАЖНО: ЕСЛИ НА ВАШ СЧЕТ НЕ ПРИШЛИ ДЕНЬГИ, НАЖМИТЕ НА КНОПКУ "✅ Я оплатил".

""",disable_web_page_preview=True,reply_markup=keyboard)   


    else:
                back =  InlineKeyboardMarkup(
            inline_keyboard=[[
                InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="back_home")
            ]]
        )
                await message.answer("😉 Пожалуйста, введите точное число:",reply_markup=back)



@dp.message_handler(state="amount_cryptobot")
async def get_price(message:types.Message,state:FSMContext):
    try:
        summa = float(message.text)
        summa  = round(float(summa) * 100) / 100 
    except:
        summa = False


    if summa: 
        if summa<10:
            await message.answer('➖ Минимальная сумма депозита 10 рублей.\n\n\n<i>Если вам нужно пополнить баланс на сумму, менее чем 10 рублей, oбращайтесь: @ser4iksupport😄</i>',reply_markup=ortga_to_main)
            await state.set_state('amount_cryptobot')
            return
        await state.finish()
        payment_details = await pay.create_invoice(amount=summa)
        bill_id = payment_details[1]
        URL = payment_details[0]
        paymentchecker.save_payment(
            bill_id=f"{bill_id}",
            amount=message.text,
            user_id=message.from_user.id,
            status="active"
        )
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton('💳 Оплатить', url=URL))
        keyboard.add(InlineKeyboardButton('✅ Я oплатил',callback_data=f"payment_cryptobot_id:{bill_id}"))
        keyboard.add(
            InlineKeyboardButton(
                '↩️ Вернуться в меню', callback_data="ortga_to_main_no_delete"
            )
        )

        await message.answer(f"""
Оплату можно произвести ниже, нажав кнопку: «Оплатить» или же нажав на: 
<a href='{URL}'>«Ссылка для оплаты»</a> 

Если вам нужно пополнить баланс на сумму, менее чем 10 рублей, а также, любые другие вопросы по платежу?
Обращайтесь😄: @ser4iksupport

💳 Cпособ оплаты: @CryptoBot 

‼️ ВАЖНО: ЕСЛИ НА ВАШ СЧЕТ НЕ ПРИШЛИ ДЕНЬГИ, НАЖМИТЕ НА КНОПКУ "✅ Я оплатил".

""",disable_web_page_preview=True,reply_markup=keyboard)   


    else:
                back =  InlineKeyboardMarkup(
            inline_keyboard=[[
                InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="back_home")
            ]]
        )
                await message.answer("😉 Пожалуйста, введите точное число:",reply_markup=back)

@dp.message_handler(state="amount_aaio")
async def get_price(message:types.Message,state:FSMContext):
    try:
        summa = float(message.text)
        summa  = round(float(summa) * 100) / 100    
    except:
        summa = False


    if summa: 
        if summa<100:
            await message.answer('➖ Минимальная сумма депозита 100 рублей.\n\n\n<i>Если вам нужно пополнить баланс на сумму, менее чем 100 рублей, oбращайтесь: @ser4iksupport😄</i>',reply_markup=ortga_to_main)
            await state.set_state('amount_aaio')
            return
        await state.finish()
        payment_details = await new_aaio_payment(amount=summa)
        bill_id = payment_details[1]
        URL = payment_details[0]
        paymentchecker.save_payment(
            bill_id=f"{bill_id}",
            amount=message.text,
            user_id=message.from_user.id,
            status="active"
        )
        keyboard = InlineKeyboardMarkup()
        keyboard.add(InlineKeyboardButton('💳 Оплатить',web_app=WebAppInfo(url=URL)))
        keyboard.add(InlineKeyboardButton('✅ Я oплатил',callback_data=f"payment_aaio_id:{bill_id}"))
        keyboard.add(
            InlineKeyboardButton(
                '↩️ Вернуться в меню', callback_data="ortga_to_main_no_delete"
            )
        )
    

        await message.answer(f"""
Оплату можно произвести ниже, нажав кнопку: «Оплатить»: 

Если вам нужно пополнить баланс на сумму, менее чем 100 рублей, а также, любые другие вопросы по платежу?
Обращайтесь😄: @ser4iksupport

💳 Cпособ оплаты: AAIO(Карты  РФ, Карты Украины, СБП, Steam skins, Perfect Money и криптоактивы)

‼️ ВАЖНО: ЕСЛИ НА ВАШ СЧЕТ НЕ ПРИШЛИ ДЕНЬГИ, НАЖМИТЕ НА КНОПКУ "✅ Я оплатил".
""",disable_web_page_preview=True,reply_markup=keyboard)   


    else:
        back =  InlineKeyboardMarkup(
            inline_keyboard=[[
                InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="back_home")
            ]]
        )
        await message.answer("😉 Пожалуйста, введите точное число:",reply_markup=back)

@dp.callback_query_handler(state="*",text_contains="payment_aaio_id:")
async def get_price(call:types.CallbackQuery,state:FSMContext):
    await state.finish()
    bill_id = call.data.replace('payment_aaio_id:','')
    data = paymentchecker.get_payment(bill_id)
    result = await check_aaio_payment(order_id=bill_id)

    if result=="OK":
        if paymentchecker.get_status(bill_id=bill_id) == "active":  
            paymentchecker.set_status(bill_id=f"{bill_id}",status="paid")
            balance.update_balance(data[0],float(data[-1]))
            await call.message.delete()
            await call.message.answer(
                text=f"✅Успешно!😄Ваш запрос на платеж одобрен, и на ваш счет добавлено {float(data[-1])} ₽ .",
                reply_markup=ortga_to_main,
            )
            level_one_invtr = ref.get_inviter(invited_user_id=call.from_user.id)
            level_two_invtr = ref.get_inviter(invited_user_id=level_one_invtr)
            if level_one_invtr is None:
                pass
            else:
                try:
                    await bot.send_message(chat_id=level_one_invtr,text=f"👥 <a href='tg://user?id={call.from_user.id}'>Ваш партнер</a> пополнил свой счет на {float(data[-1])} ₽ и вы получили бонус в размере {float(data[-1])*0.15} ₽(15%) на реферальный баланс.")
                    ref_balance.update_balance(user_id=level_one_invtr,amount=float(data[-1])*0.15)
                    ref_all_balance.update_balance(user_id=level_one_invtr,amount=float(data[-1])*0.15)
                except:pass
                if level_two_invtr is None or level_two_invtr is False:
                    pass
                else:
                    try:
                        await bot.send_message(chat_id=level_two_invtr,text=f"👥 <a href='tg://user?id={call.from_user.id}'>Партнер</a> вашего <a href='tg://user?id={level_one_invtr}'>партнёра</a> пополнил свой счёт на {float(data[-1])} ₽. Вам начислен бонус в размере {float(data[-1])*0.03} ₽(3%) от пополнения на реферальный баланс.")
                        ref_balance.update_balance(user_id=level_two_invtr,amount=float(data[-1])*0.03)
                        ref_all_balance.update_balance(user_id=level_two_invtr,amount=float(data[-1])*0.03)
                    except:pass
        else:
            await call.message.delete()
                    
        
                 
                        
    elif result=="NotPaid":await call.answer("""❌Пожалуйста, нажмите эту кнопку после оплаты!\n🧑🏻‍💻Если это ошибка, обратитесь в нашу Техническую поддержку. @Ser4ikSupport""")
    elif result=="Expired":await call.answer("""💥Устаревшая ссылка. 🧑🏻‍💻Если это ошибка, Свяжитесь со службой технической поддержки. @Ser4ikSupport""")

@dp.callback_query_handler(state="*",text_contains="payment_cryptobot_id:")
async def get_price(call:types.CallbackQuery,state:FSMContext):
    await state.finish()
    bill_id = call.data.replace('payment_cryptobot_id:','')
    data = paymentchecker.get_payment(bill_id)
    result = await pay.check_invoice(invoice_id=bill_id)

    if result=="paid":
        if paymentchecker.get_status(bill_id=bill_id) == "active":  
            paymentchecker.set_status(bill_id=f"{bill_id}",status="paid")
            balance.update_balance(data[0],float(data[-1]))
            await call.message.delete()
            await call.message.answer(
                text=f"✅Успешно!😄Ваш запрос на платеж одобрен, и на ваш счет добавлено {float(data[-1])} ₽ .",
                reply_markup=ortga_to_main,
            )
            level_one_invtr = ref.get_inviter(invited_user_id=call.from_user.id)
            level_two_invtr = ref.get_inviter(invited_user_id=level_one_invtr)
            if level_one_invtr is None:
                pass
            else:
                try:
                    await bot.send_message(chat_id=level_one_invtr,text=f"👥 <a href='tg://user?id={call.from_user.id}'>Ваш партнер</a> пополнил свой счет на {float(data[-1])} ₽ и вы получили бонус в размере {float(data[-1])*0.15} ₽(15%) на реферальный баланс.")
                    ref_balance.update_balance(user_id=level_one_invtr,amount=float(data[-1])*0.15)
                    ref_all_balance.update_balance(user_id=level_one_invtr,amount=float(data[-1])*0.15)
                except:pass
                if level_two_invtr is None or level_two_invtr is False:
                    pass
                else:
                    try:
                        await bot.send_message(chat_id=level_two_invtr,text=f"👥 <a href='tg://user?id={call.from_user.id}'>Партнер</a> вашего <a href='tg://user?id={level_one_invtr}'>партнёра</a> пополнил свой счёт на {float(data[-1])} ₽. Вам начислен бонус в размере {float(data[-1])*0.03} ₽(3%) от пополнения на реферальный баланс.")
                        ref_balance.update_balance(user_id=level_two_invtr,amount=float(data[-1])*0.03)
                        ref_all_balance.update_balance(user_id=level_two_invtr,amount=float(data[-1])*0.03)
                    except:pass
        else:
            await call.message.delete()
                    
    elif result=="active":await call.answer("""❌Пожалуйста, нажмите эту кнопку после оплаты!\n🧑🏻‍💻Если это ошибка, обратитесь в нашу Техническую поддержку. @Ser4ikSupport""")
    elif result=="expired":await call.answer("""💥Устаревшая ссылка. 🧑🏻‍💻Если это ошибка, Свяжитесь со службой технической поддержки. @Ser4ikSupport""")

@dp.callback_query_handler(state="*",text_contains="payment_payeer_id:")
async def get_price(call:types.CallbackQuery,state:FSMContext):
    await state.finish()
    bill_id = call.data.replace('payment_payeer_id:','')
    data = paymentchecker.get_payment(bill_id)
    result = await payeer.check_invoice(invoice_id=bill_id)

    if result=="paid":
        if paymentchecker.get_status(bill_id=bill_id) == "active":  
            paymentchecker.set_status(bill_id=f"{bill_id}",status="paid")
            balance.update_balance(data[0],float(data[-1]))
            await call.message.delete()
            await call.message.answer(
                text=f"✅Успешно!😄Ваш запрос на платеж одобрен, и на ваш счет добавлено {float(data[-1])} ₽ .",
                reply_markup=ortga_to_main,
            )
            level_one_invtr = ref.get_inviter(invited_user_id=call.from_user.id)
            level_two_invtr = ref.get_inviter(invited_user_id=level_one_invtr)
            if level_one_invtr is None:
                pass
            else:
                try:
                    await bot.send_message(chat_id=level_one_invtr,text=f"👥 <a href='tg://user?id={call.from_user.id}'>Ваш партнер</a> пополнил свой счет на {float(data[-1])} ₽ и вы получили бонус в размере {float(data[-1])*0.15} ₽(15%) на реферальный баланс.")
                    ref_balance.update_balance(user_id=level_one_invtr,amount=float(data[-1])*0.15)
                    ref_all_balance.update_balance(user_id=level_one_invtr,amount=float(data[-1])*0.15)
                except:pass
                if level_two_invtr is None or level_two_invtr is False:
                    pass
                else:
                    try:
                        await bot.send_message(chat_id=level_two_invtr,text=f"👥 <a href='tg://user?id={call.from_user.id}'>Партнер</a> вашего <a href='tg://user?id={level_one_invtr}'>партнёра</a> пополнил свой счёт на {float(data[-1])} ₽. Вам начислен бонус в размере {float(data[-1])*0.03} ₽(3%) от пополнения на реферальный баланс.")
                        ref_balance.update_balance(user_id=level_two_invtr,amount=float(data[-1])*0.03)
                        ref_all_balance.update_balance(user_id=level_two_invtr,amount=float(data[-1])*0.03)
                    except:pass
        else:
            await call.message.delete()
                    
    elif result=="active":await call.answer("""❌Пожалуйста, нажмите эту кнопку после оплаты!\n🧑🏻‍💻Если это ошибка, обратитесь в нашу Техническую поддержку. @Ser4ikSupport""")
    elif result=="expired":await call.answer("""💥Устаревшая ссылка. 🧑🏻‍💻Если это ошибка, Свяжитесь со службой технической поддержки. @Ser4ikSupport""")


@dp.callback_query_handler(state="*",text_contains="payment_xrocket_id:")
async def get_price(call:types.CallbackQuery,state:FSMContext):
    await state.finish()
    bill_id = call.data.replace('payment_xrocket_id:','')
    data = paymentchecker.get_payment(bill_id)
    result = rocket.check_invoice(invoice_id=bill_id)

    if result=="paid":
        if paymentchecker.get_status(bill_id=bill_id) == "active":  
            paymentchecker.set_status(bill_id=f"{bill_id}",status="paid")
            balance.update_balance(data[0],float(data[-1]))
            await call.message.delete()
            await call.message.answer(
                text=f"✅Успешно!😄Ваш запрос на платеж одобрен, и на ваш счет добавлено {float(data[-1])} ₽ .",
                reply_markup=ortga_to_main,
            )
            level_one_invtr = ref.get_inviter(invited_user_id=call.from_user.id)
            level_two_invtr = ref.get_inviter(invited_user_id=level_one_invtr)
            if level_one_invtr is None:
                pass
            else:
                try:
                    await bot.send_message(chat_id=level_one_invtr,text=f"👥 <a href='tg://user?id={call.from_user.id}'>Ваш партнер</a> пополнил свой счет на {float(data[-1])} ₽ и вы получили бонус в размере {float(data[-1])*0.15} ₽(15%) на реферальный баланс.")
                    ref_balance.update_balance(user_id=level_one_invtr,amount=float(data[-1])*0.15)
                    ref_all_balance.update_balance(user_id=level_one_invtr,amount=float(data[-1])*0.15)
                except:pass
                if level_two_invtr is None or level_two_invtr is False:
                    pass
                else:
                    try:
                        await bot.send_message(chat_id=level_two_invtr,text=f"👥 <a href='tg://user?id={call.from_user.id}'>Партнер</a> вашего <a href='tg://user?id={level_one_invtr}'>партнёра</a> пополнил свой счёт на {float(data[-1])} ₽. Вам начислен бонус в размере {float(data[-1])*0.03} ₽(3%) от пополнения на реферальный баланс.")
                        ref_balance.update_balance(user_id=level_two_invtr,amount=float(data[-1])*0.03)
                        ref_all_balance.update_balance(user_id=level_two_invtr,amount=float(data[-1])*0.03)
                    except:pass
        else:
            await call.message.delete()
                    
    elif result=="active":await call.answer("""❌Пожалуйста, нажмите эту кнопку после оплаты!\n🧑🏻‍💻Если это ошибка, обратитесь в нашу Техническую поддержку. @Ser4ikSupport""")
    elif result=="expired":await call.answer("""💥Устаревшая ссылка. 🧑🏻‍💻Если это ошибка, Свяжитесь со службой технической поддержки. @Ser4ikSupport""")

