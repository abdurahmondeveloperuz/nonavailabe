from aiogram import Bot, Dispatcher, types
from aiogram.contrib.fsm_storage.memory import MemoryStorage
from utils.db_api.sqlite import Database,UserBalanceDB,Channel,BanUser,ProductPriceDB,PaymentChecker,SoldNumbers,FileIDSaver,ReferallBalanceDB, Referalls
from data import config
from apscheduler.schedulers.asyncio import AsyncIOScheduler

bot = Bot(token=config.BOT_TOKEN, parse_mode=types.ParseMode.HTML)
storage = MemoryStorage()
dp = Dispatcher(bot, storage=storage)
db = Database(path_to_db="data/main.db")
balance = UserBalanceDB("data/user_balances.db")
price = ProductPriceDB("data/product_prices.db")
paymentchecker = PaymentChecker("data/payment_checker.db")
soldnumbers = SoldNumbers("data/sold_numbers.db")
channels = Channel("data/main.db")
banuser = BanUser("main.db")
fileid = FileIDSaver("data/main.db")
ref_all_balance = ReferallBalanceDB("data/allfunds.db")
ref_balance = ReferallBalanceDB("data/refbalance.db")
ref = Referalls("data/ref.db")
sched = AsyncIOScheduler()
