from environs import Env
env = Env()
env.read_env()
BOT_TOKEN = "6381495585:AAHVTlf7O85hY3r_Y_Ivx99DtT1bR5ov8mI"  
ADMINS = env.list("ADMINS") 
IP = env.str("ip")  
fivesimnettoken = env.str('SIM_NET_API_TOKEN')
