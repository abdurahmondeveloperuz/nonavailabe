import logging
from aiogram import types
from aiogram.dispatcher.handler import CancelHandler
from aiogram.dispatcher.middlewares import BaseMiddleware
from aiogram.types import InlineKeyboardButton,InlineKeyboardMarkup
from loader import channels
from utils.misc import subscription
from loader import banuser,bot, ref
import datetime
import sqlite3

class BigBrother(BaseMiddleware):
    async def on_pre_process_update(self,update:types.Update,data:dict):
        if update.message:
            user = update.message.from_user.id
            args = update.message.get_args()

            if args:
                try:
                    user_mention = update.message.from_user.get_mention(as_html=True)
                except Exception as e:
                    print(e)
                else:
                    res = ref.add_ref(invitor_user_id=args,invited_user_id=user)
                    if res == "self_invite":
                        await update.message.answer("❌ Вы не можете пригласить себя")
                    elif res:  
                        await bot.send_message(chat_id=args,text=f'👥 Вы пригласили {user_mention}, когда ваш партнер подпишется на каналы вам будут доступны бонусы.')
                        ref.set_status(invited_user_id=user,status="notrewarded")
                  
            else:
                res = ref.add_ref(invitor_user_id=None,invited_user_id=user, status="rewarded")

        elif update.callback_query:           
            user = update.callback_query.from_user.id
            if update.callback_query.data == "check_subs":
                await update.callback_query.message.delete()

        else:
            return


        if banuser.check_user(user):
            btn = InlineKeyboardMarkup(row_width=1)
            btn.add(
                InlineKeyboardButton(
                    text="👮‍♂️Админ",
                    url="https://t.me/Ser4ikSupport",
                )
            )
            if update.message:
                await update.message.answer("<b>❌Вы заблокированы в боте!</b>\n\n\n<i>👇🏻 Вы можете извиниться перед администратором и разблокироваться, нажав кнопку ниже!</i>",reply_markup=btn)
            else:
                await update.callback_query.message.answer("<b>❌Вы заблокированы в боте!</b>\n\n\n<i>👇🏻 Вы можете извиниться перед администратором и разблокироваться, нажав кнопку ниже!</i>",reply_markup=btn)
            raise CancelHandler()

        buttons = InlineKeyboardMarkup(row_width=1)
        final_status = True
        CHANNELS = channels.get_channels()
        for channel in CHANNELS:
            status = await subscription.check(user_id=user, channel=channel)
            final_status *= status
            channel = await bot.get_chat(channel)
            if not status:
                invite_link = await channel.export_invite_link()
                buttons.add(InlineKeyboardButton(text=f"{channel.title}",url=f"{invite_link}"))
        if not final_status:

            buttons.add(
                InlineKeyboardButton(
                    text="✅ Я подписался/ась", callback_data="check_subs"
                )
            )
            if update.message:await update.message.answer('⚠️ Чтобы пользоваться ботом, подпишитесь на канал ниже:',reply_markup=buttons)
            else:await update.callback_query.message.answer('⚠️ Чтобы пользоваться ботом, подпишитесь на канал ниже:',reply_markup=buttons)
            raise CancelHandler()
        
        
        

