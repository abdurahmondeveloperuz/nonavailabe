from aiogram.types import ReplyKeyboardMarkup,KeyboardButton
from aiogram.types import InlineKeyboardButton,InlineKeyboardMarkup
buttons = InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton("📱 Купить номер",callback_data="buy_number"),
        InlineKeyboardButton("🔝 Пополнить баланс",callback_data="top_balance"),

    ],
    [
        InlineKeyboardButton("📞 Купленные номера",callback_data="soldnumbers"),

        InlineKeyboardButton("👥 Peф. система",callback_data="refsystem")
    ],
    [
        InlineKeyboardButton("🗒 Правила | Инструкция",callback_data="instruction_rules"),

    ]
])

choice = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="🌐 CryptoBot", callback_data="cryptobot_topup"),
            InlineKeyboardButton(text="🚀 XRocket", callback_data="xrocket_topup")
        ],
        [
            InlineKeyboardButton(text="🇷🇺 Карты РФ", callback_data="aaio_topup"),
            InlineKeyboardButton(text="🇺🇦 Карты Украины", callback_data="aaio_topup")
        ],
        [
            InlineKeyboardButton(text="💳 СБП", callback_data="aaio_topup"),
            InlineKeyboardButton(text="⚫️ Steam", callback_data="aaio_topup")
        ],
        [
            InlineKeyboardButton(text="🔴 Perfect Money", callback_data="aaio_topup"),
            InlineKeyboardButton(text="🅿️ Payeer", callback_data="payeer_topup")
        ],
        [
            InlineKeyboardButton(text="☄️ Криптовалюты", callback_data="aaio_topup"),
            InlineKeyboardButton(text="💠 Freekassa", callback_data="aaio_topup")
        ],
        [
            InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")
        ]
    ]
)

payout_key = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="💸 Вывод на баланс бота", callback_data="payoutbot")
        ],
        [
            InlineKeyboardButton(text="💸 Вывод на карту", callback_data="payoutcard")
        ],
        [
            InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")
        ]
    ]
)
ortga_to_panel =  InlineKeyboardMarkup(
    inline_keyboard=[[
        InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_panel")
    ]]
)
ortga_to_main =  InlineKeyboardMarkup(
    inline_keyboard=[[
        InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")
    ]]
)
back_main_home =  InlineKeyboardMarkup(
    inline_keyboard=[[
        InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")
    ]]
)

panel_tugma = InlineKeyboardMarkup(
    inline_keyboard=[
        [
            InlineKeyboardButton(text="📣 Отправить объявление", callback_data='admin:send_ad'),
            InlineKeyboardButton(text="🗄 Загрузка базы", callback_data='admin:base'),

        ],
        [

            InlineKeyboardButton(text="❌ Удаление пользователей", callback_data='admin:delete_users'),
            InlineKeyboardButton(text="🚫 Блокировка", callback_data='admin:block'),

        ],
        [
            InlineKeyboardButton(text="💰 Цены на номера",callback_data="tnp"),
            InlineKeyboardButton(text="💰 Баланс API ",callback_data="balance_api"),

        ],
        [
            InlineKeyboardButton(text="📢 Настройка канала",callback_data="admin:channels"),
            InlineKeyboardButton(text="👤 Cообщение пользователю", callback_data='admin:send_user'),

        ],
        [
            InlineKeyboardButton(text="👤 Пользовательские настройки",callback_data='users_settings'),

        ]
    ],
)

type_change_price = InlineKeyboardMarkup(
    inline_keyboard=[
    [
        InlineKeyboardButton(text="👉 Обновлять вpучно",callback_data="number_prices"),
    ],
    [
        InlineKeyboardButton(text="👉 Обновлять aвтоматическo", callback_data="auto_change_price")

    ],
        [
InlineKeyboardButton(text="◀️ Вернуться в панель администратора", callback_data='GoToAdminPanel')
        ]
])
change_price_labels = InlineKeyboardMarkup(
    inline_keyboard=[
    [
        InlineKeyboardButton(text="+5 ₽",callback_data="roubles_5"),
        InlineKeyboardButton(text="+10 ₽",callback_data="roubles_10"),
        InlineKeyboardButton(text="+15 ₽",callback_data="roubles_15")
    ],
    [
        InlineKeyboardButton(text="+20 ₽",callback_data="roubles_20"),
        InlineKeyboardButton(text="+25 ₽",callback_data="roubles_25"),
        InlineKeyboardButton(text="+30 ₽",callback_data="roubles_30")
    ],
[
        InlineKeyboardButton(text="-5 ₽",callback_data="roubles_-5"),
        InlineKeyboardButton(text="-10 ₽",callback_data="roubles_-10"),
        InlineKeyboardButton(text="-15 ₽",callback_data="roubles_-15")
    ],
    [
        InlineKeyboardButton(text="-20 ₽",callback_data="roubles_-20"),
        InlineKeyboardButton(text="-25 ₽",callback_data="roubles_-25"),
        InlineKeyboardButton(text="-30 ₽",callback_data="roubles_-30")
    ],
    [
        InlineKeyboardButton(text="📝 Вводимое значение",callback_data="entered_value")
    ],
    [
        InlineKeyboardButton(text="◀️ Вернуться в панель администратора", callback_data='GoToAdminPanel')
    ]
])
numbers_list_one = InlineKeyboardMarkup(
    inline_keyboard=[
    [
        InlineKeyboardButton(text="🍭 Instagram",callback_data="instagram"),
        InlineKeyboardButton(text="🍭 Facebook",callback_data="facebook")
    ],
    [
        InlineKeyboardButton(text="🍭 Ebay",callback_data="ebay"),
        InlineKeyboardButton(text="🍭 Tinder",callback_data="tinder")

    ],
    [
        InlineKeyboardButton(text="🍭 Telegram",callback_data="telegram"),
        InlineKeyboardButton(text="🍭 Uber",callback_data="uber")
    ],
    [
        InlineKeyboardButton(text="🍭 Twitter",callback_data="twitter"),
        InlineKeyboardButton(text="🍭 WhatsApp",callback_data="whatsup")
    ],
    [
        InlineKeyboardButton(text="🍭 Vkontakte",callback_data="vkontakte"),
        InlineKeyboardButton(text="🍭 Tik Tok",callback_data="tiktok")
    ],

    [
        InlineKeyboardButton(text="➡️ Вперед",callback_data="next"),
    ],[

        InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")
]
])

numbers_list_two = InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton(text="🍭 Yandex",callback_data="yandex"),
        InlineKeyboardButton(text="🍭 Google",callback_data="gmail"),

    ],
    [  
        InlineKeyboardButton(text="🍭 Amazon",callback_data="amazon"),
        InlineKeyboardButton(text="🍭 Discord",callback_data="discord")
    ],
    [
        InlineKeyboardButton(text="🍭 Microsoft",callback_data="microsoft"),
        InlineKeyboardButton(text="🍭 Apple",callback_data="apple")
    ],
    [
        InlineKeyboardButton(text="🍭 Avito",callback_data="avito"),
        InlineKeyboardButton(text="🍭 Steam",callback_data="steam")
        
    ],
    [
        InlineKeyboardButton(text="🍭 SberMarket",callback_data="sbermarket"),
 
    ],
    [
        InlineKeyboardButton(text="⬅️ Назад",callback_data="previus"),

    ],
    
    [

        InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_to_main")

    ]
])


numbers_list_one_admin = InlineKeyboardMarkup(
    inline_keyboard=[
    [
        InlineKeyboardButton(text="🍭 Instagram",callback_data="instagram_edit"),
        InlineKeyboardButton(text="🍭 Facebook",callback_data="facebook_edit")
    ],
    [
        InlineKeyboardButton(text="🍭 Ebay",callback_data="ebay_edit"),
        InlineKeyboardButton(text="🍭 Tinder",callback_data="tinder_edit")

    ],
    [
        InlineKeyboardButton(text="🍭 Telegram",callback_data="telegram_edit"),
        InlineKeyboardButton(text="🍭 Uber",callback_data="uber_edit")
    ],
    [
        InlineKeyboardButton(text="🍭 Twitter",callback_data="twitter_edit"),
        InlineKeyboardButton(text="🍭 WhatsApp",callback_data="whatsup_edit")
    ],
    [
        InlineKeyboardButton(text="🍭 Vkontakte",callback_data="vkontakte_edit"),
        InlineKeyboardButton(text="🍭 Tik Tok",callback_data="tiktok_edit")
    ],
    [
        InlineKeyboardButton(text="➡️ Вперед",callback_data="next_edit"),
    ],
    [
        InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_panel")

    ]
])

numbers_list_two_admin = InlineKeyboardMarkup(inline_keyboard=[
    [
        InlineKeyboardButton(text="🍭 Yandex",callback_data="yandex_edit"),
        InlineKeyboardButton(text="🍭 Google",callback_data="gmail_edit"),

    ], 
    [
        InlineKeyboardButton(text="🍭 Amazon",callback_data="amazon_edit"),
        InlineKeyboardButton(text="🍭 Discord",callback_data="discord_edit")
    ],
    [
        InlineKeyboardButton(text="🍭 Microsoft",callback_data="microsoft_edit"),
        InlineKeyboardButton(text="🍭 Apple",callback_data="apple_edit")
    ],
    [
        InlineKeyboardButton(text="🍭 Avito",callback_data="avito_edit"),
        InlineKeyboardButton(text="🍭 Steam",callback_data="steam_edit")
    
    ],
    [
        InlineKeyboardButton(text="🍭 SberMarket",callback_data="sbermarket_edit"),
 
    ],
    [
        InlineKeyboardButton(text="⬅️ Назад",callback_data="previus_edit"),

    ],

[
        InlineKeyboardButton(text="↩️ Вернуться в меню", callback_data="ortga_panel")
]
])


