import aiohttp
import asyncio
from AaioAPI import AsyncAaioAPI
from uuid import uuid4
import requests

async def async_request(url, headers={}, data={}, get=True):
    async with aiohttp.ClientSession() as session:
            if get:
                async with session.get(url, headers=headers, data=data) as response:
                    res = await response.json()
                    return res
            async with session.post(url, headers=headers, data=data) as response:
                res = await response.json()
                return res
            
    
class XRocket:
    def __init__(self, token) -> None:
        self.token = token
        self.__url = f"https://pay.ton-rocket.com/tg-invoices"
        self.__headers = {
            "Rocket-Pay-Key": f'{self.token}',
            "Content-Type": "application/json",
            'accept': 'application/json'
        }
        
    def fiat_converter(self, amount, currency, fiat='RUB'):
        data = requests.get(f"https://trade.ton-rocket.com/rates/fiat/{currency}/{fiat}").json()
        rate = data['data']['rate']
        value = float(amount) / float(rate)
        value = round(value, 4)
        return value
    
    def get_ton_invoice(self, amount) -> None:
        toncoin = self.fiat_converter(amount=amount, currency="TONCOIN")
        toncoin_data = {"amount": toncoin,"numPayments": 1,'currency':f'TONCOIN',"description": "@Ser4ikShopBot TopUp balance","hiddenMessage": "Back to Bot and Press '\''✅I paid'\''","commentsEnabled": False,"callbackUrl": "https://t.me/Ser4ikShopBot","expiredIn": 1200}
        toncoin_invoice = requests.post(url=self.__url, headers=self.__headers, json=toncoin_data).json()
        ton_invoice = [toncoin_invoice['data']['link'], toncoin_invoice['data']['id']]
        return ton_invoice
    
    def get_not_invoice(self, amount) -> None:
        notcoin = self.fiat_converter(amount=amount, currency="NOT")
        notcoin_data = {
            "amount": notcoin,
            "currency":"NOT",
            "numPayments": 1,
            "description": "@Ser4ikShopBot TopUp balance",
            "hiddenMessage": "Back to Bot and Press ✅I paid",
            "commentsEnabled": False,
            "callbackUrl": "https://t.me/Ser4ikShopBot",
            "expiredIn": 1200
        }
        notcoin_invoice = requests.post(url=self.__url, headers=self.__headers, json=notcoin_data).json()
        print(notcoin_invoice)
        not_invoice = [notcoin_invoice['data']['link'], notcoin_invoice['data']['id']]
        return not_invoice
    
    def get_usd_invoice(self, amount) -> None:
        usdt = self.fiat_converter(amount=amount, currency="USDT")
        usdt_data = {"amount": usdt,'currency':f'USDT',"numPayments": 1,"description": "@Ser4ikShopBot TopUp balance","hiddenMessage": "Back to Bot and Press '\''✅I paid'\''","commentsEnabled": False,"callbackUrl": "https://t.me/Ser4ikShopBot","expiredIn": 1200}
        usdt_invoice = requests.post(url=self.__url, headers=self.__headers, json=usdt_data).json()
        usd_invoice = [usdt_invoice['data']['link'], usdt_invoice['data']['id']]
    
        return usd_invoice
    
    def create_invoice(self, amount, currency) -> None:
        if currency == "ton":
            invoice = self.get_ton_invoice(amount=amount)
        elif currency == "not":
            invoice = self.get_not_invoice(amount=amount)
        else:
            invoice = self.get_usd_invoice(amount=amount)
        return invoice
    
    def check_invoice(self, invoice_id):
        invoice = requests.get(f"https://pay.ton-rocket.com/tg-invoices/{invoice_id}", headers=self.__headers).json()
        return invoice['data']['status']

    
class CryptoBot:
    def __init__(self, token) -> None:
        self.token = token
        self.__url = f"https://pay.crypt.bot/api"
        self.__headers = {
            "Crypto-Pay-API-Token": self.token,
            "content_type": "application/json"
        } 

    async def create_invoice(self, amount, currency_type="fiat", asset="RUB", paid_btn_url="https://t.me/Ser4ikShopBot", paid_btn_name="callback", description="Оплата @Ser4ikShopBot") -> None:
        invoice =  await async_request(f"{self.__url}/createInvoice?amount={amount}&currency_type={currency_type}&fiat={asset}&paid_btn_name={paid_btn_name}&paid_btn_url={paid_btn_url}&description={description}&allow_comments=False&allow_anonymous=False",headers=self.__headers)
        return [invoice["result"]["mini_app_invoice_url"],invoice["result"]["invoice_id"]]
    
    async def get_invoice(self, invoice_id):
        invoice =  await async_request(f"{self.__url}/getInvoices?invoice_ids={invoice_id}",headers=self.__headers)
        return invoice["result"]["items"]
    
    async def check_invoice(self, invoice_id):
        invoice =  await async_request(f"{self.__url}/getInvoices?invoice_ids={invoice_id}",headers=self.__headers)
        return invoice["result"]["items"][0]["status"]
    
    async def get_me(self):
        return await async_request(f"{self.__url}/getMe",headers=self.__headers)

class Payeer:
    def __init__(self) -> None:
        self.__url = "https://payeer.com/ajax/api/api.php?InvoiceCreate"
        self.__headers = {'Content-Type': 'application/x-www-form-urlencoded'}

    async def create_invoice(self, amount, asset="RUB",description="Оплата @Ser4ikShopBot") -> None:
        invoice_id = str(uuid4())
        data = {
            "account": "P1119244417",
            "apiId": "2100618220",
            "apiPass": "abdurahmondev_2010",
            "action": "invoiceCreate",
            "m_shop": "2096952991",
            "m_orderid": invoice_id,
            "m_amount": amount,
            "m_curr": asset,
            "m_desc": description
        }
        invoice =  await async_request(f"{self.__url}",headers=self.__headers, data=data, get=False)
        return [invoice["url"], invoice_id]

    async def get_invoice(self, invoice_id):
        data = {
            "account": "P1119244417",
            "apiId": "2100618220",
            "apiPass": "abdurahmondev_2010",
            "action": "paymentDetails",
            "merchantId": "2096952991",
            "referenceId": invoice_id
        }
        invoice =  await async_request(f"{self.__url}", headers=self.__headers, data=data, get=False)
        return invoice["items"][0]

    async def check_invoice(self, invoice_id):
        data = {
            "account": "P1119244417",
            "apiId": "2100618220",
            "apiPass": "abdurahmondev_2010",
            "action": "paymentDetails",
            "merchantId": "2096952991",
            "referenceId": invoice_id
        }
        invoice =  await async_request(f"{self.__url}", headers=self.__headers, data=data, get=False)
        return 'paid' if invoice["success"] else "active"


async def new_aaio_payment(amount,lang="ru",currency='RUB',desc='📩 @Ser4ikShopBot Payment'):
    client = AsyncAaioAPI('YzU5MDcyZjgtNzRmYi00ZmZkLTk3ZTUtNDg3NjBmNTcwZDY2OjBpMG15N3h0X3BtVFlmaGxlM2JIOTBPYndSVG5BS3ds', '5614b691cc1a9d9085e983c6944e89bf', '78b89468-7c57-45c8-8c66-0d33e8a2fdc5')
    order_id = str(uuid4())
    URLPayment = await client.create_payment(order_id, amount, lang, currency, desc)
    return [URLPayment,order_id] 

async def check_aaio_payment(order_id):
    client = AsyncAaioAPI('YzU5MDcyZjgtNzRmYi00ZmZkLTk3ZTUtNDg3NjBmNTcwZDY2OjBpMG15N3h0X3BtVFlmaGxlM2JIOTBPYndSVG5BS3ds', '5614b691cc1a9d9085e983c6944e89bf', '78b89468-7c57-45c8-8c66-0d33e8a2fdc5')
    if await client.is_expired(order_id):                
        return "Expired"
    elif await client.is_success(order_id):              
        return "OK"
    else:                                  
        return "NotPaid"


if __name__ == "__main__":
    pay = CryptoBot(token="12879:AAir29cCEu9WWVqQslovLRlHkD2EA4FnMjF")
    m = asyncio.run(pay.create_invoice(amount=10))
    print(m)
