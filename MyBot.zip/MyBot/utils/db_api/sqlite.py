import sqlite3
from datetime import datetime
class Database:
    def __init__(self, path_to_db="main.db"):
        self.path_to_db = path_to_db

    @property
    def connection(self):
        return sqlite3.connect(self.path_to_db)

    def execute(self, sql: str, parameters: tuple = None, fetchone=False, fetchall=False, commit=False):
        if not parameters:
            parameters = ()
        connection = self.connection
        # connection.set_trace_callback(logger)
        cursor = connection.cursor()
        data = None
        cursor.execute(sql, parameters)

        if commit:
            connection.commit()
        if fetchall:
            data = cursor.fetchall()
        if fetchone:
            data = cursor.fetchone()
        connection.close()
        return data

    def create_table_users(self):
        sql = """
        CREATE TABLE IF NOT EXISTS Users (
            id int NOT NULL,
            fullname varchar(255) NOT NULL,
            username varchar(255),
            PRIMARY KEY (id)
            );
"""
        self.execute(sql, commit=True)

    @staticmethod
    def format_args(sql, parameters: dict):
        sql += " AND ".join([
            f"{item} = ?" for item in parameters
        ])
        return sql, tuple(parameters.values())

    def add_user(self, id: int, fullname: str, username: str):
        sql = """
        INSERT INTO Users(id, fullname, username) VALUES(?, ?, ?)
        """
        self.execute(sql, parameters=(id, fullname, username), commit=True)

    def select_all_users(self):
        sql = """
        SELECT * FROM Users
        """
        return self.execute(sql, fetchall=True)

    def select_user(self, **kwargs):
        sql = "SELECT * FROM Users WHERE "
        sql, parameters = self.format_args(sql, kwargs)

        return self.execute(sql, parameters=parameters, fetchone=True)

    def count_users(self):
        return self.execute("SELECT COUNT(*) FROM Users;", fetchone=True)

    def delete_users(self):
        self.execute("DELETE FROM Users WHERE TRUE", commit=True)


class UserBalanceDB:
    def __init__(self, db_file):
        self.conn = sqlite3.connect(db_file)
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS accounts
                            (user_id INTEGER PRIMARY KEY, balance REAL)''')
        self.conn.commit()

    def update_balance(self, user_id, amount):
        current_balance = self.get_balance(user_id)
        new_balance = current_balance + float(amount)
        self.cursor.execute('UPDATE accounts SET balance = ? WHERE user_id = ?', (new_balance, user_id))
        self.conn.commit()

    def minus_balance(self, user_id, amount):
        current_balance = self.get_balance(user_id)
        new_balance = current_balance - float(amount)
        self.cursor.execute('UPDATE accounts SET balance = ? WHERE user_id = ?', (new_balance, user_id))
        self.conn.commit()

    def set_balance(self, user_id, amount):
        self.cursor.execute('INSERT OR REPLACE INTO accounts (user_id, balance) VALUES (?, ?)', (user_id, float(amount)))
        self.conn.commit()

    def get_balance(self, user_id):
        self.cursor.execute('SELECT balance FROM accounts WHERE user_id = ?', (user_id,))
        if result := self.cursor.fetchone():
            return result[0]
        self.set_balance(user_id, 0)
        return 0
            
        

class ReferallBalanceDB:
    def __init__(self, db_file):
        self.conn = sqlite3.connect(db_file)
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS accounts
                            (user_id INTEGER PRIMARY KEY, balance REAL)''')
        self.conn.commit()

    def update_balance(self, user_id, amount):
        current_balance = self.get_balance(user_id)
        new_balance = current_balance + float(amount)
        self.cursor.execute('UPDATE accounts SET balance = ? WHERE user_id = ?', (new_balance, user_id))
        self.conn.commit()

    def minus_balance(self, user_id, amount):
        current_balance = self.get_balance(user_id)
        new_balance = current_balance - float(amount)
        self.cursor.execute('UPDATE accounts SET balance = ? WHERE user_id = ?', (new_balance, user_id))
        self.conn.commit()

    def set_balance(self, user_id, amount):
        self.cursor.execute('INSERT OR REPLACE INTO accounts (user_id, balance) VALUES (?, ?)', (user_id, float(amount)))
        self.conn.commit()

    def get_balance(self, user_id):
        self.cursor.execute('SELECT balance FROM accounts WHERE user_id = ?', (user_id,))
        if result := self.cursor.fetchone():
            return result[0]
        self.set_balance(user_id, 0)
        return 0

            


class Referalls:
    def __init__(self, db_file):
        self.conn = sqlite3.connect(db_file)
        self.cursor = self.conn.cursor()
        self.cursor.execute("""CREATE TABLE IF NOT EXISTS referrals (
                                invitor_user_id TEXT,
                                invited_user_id TEXT,
                                status TEXT
                                );""")
        self.conn.commit()

    def add_ref(self, invitor_user_id, invited_user_id, status=None):
        if str(invited_user_id) == str(invitor_user_id):
            return "self_invite"
        self.cursor.execute("SELECT * FROM referrals WHERE invited_user_id = ?", (invited_user_id,))
        row = self.cursor.fetchone()

        if row is not None:
            return False

        self.cursor.execute("INSERT INTO referrals VALUES (?, ?, ?)", (invitor_user_id, invited_user_id, status))
        self.conn.commit()
        return True

    def set_status(self, invited_user_id, status):
        self.cursor.execute("UPDATE referrals SET status = ? WHERE invited_user_id = ?", (status, invited_user_id))
        self.conn.commit()
        return True

    def get_status(self, invited_user_id):
        self.cursor.execute("SELECT status FROM referrals WHERE invited_user_id = ?", (invited_user_id,))
        row = self.cursor.fetchone()

        return False if row is None else row[0]
    def get_ref_count(self, invitor_user_id):
        self.cursor.execute("SELECT COUNT(*) FROM referrals WHERE invitor_user_id = ?", (invitor_user_id,))
        return self.cursor.fetchone()[0]
        
    def get_inviter(self, invited_user_id):
        self.cursor.execute("SELECT invitor_user_id FROM referrals WHERE invited_user_id = ?",(invited_user_id,))
        row = self.cursor.fetchone()
        return False if row is None else row[0]
    def get_rewarded(self, invitor_user_id):
        if invitor_user_id:
            self.cursor.execute("SELECT invited_user_id FROM referrals WHERE status = 'rewarded' AND invitor_user_id = ?", (invitor_user_id,))
        else:
            self.cursor.execute("SELECT invited_user_id FROM referrals WHERE status = 'rewarded'")
        rows = self.cursor.fetchall()
        return len([row[0] for row in rows])

    def get_notrewarded(self, invitor_user_id):
        if invitor_user_id:
            self.cursor.execute("SELECT invited_user_id FROM referrals WHERE status != 'rewarded' AND invitor_user_id = ?", (invitor_user_id,))
        else:
            self.cursor.execute("SELECT invited_user_id FROM referrals WHERE status != 'rewarded'")
        rows = self.cursor.fetchall()
        return len([row[0] for row in rows])

class ProductPriceDB:
    def __init__(self, db_name):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute("""
            CREATE TABLE IF NOT EXISTS product_prices (
                product_name TEXT PRIMARY KEY,
                price REAL
            )
        """)
        self.conn.commit()

    def save_price(self, name, price):
        self.cursor.execute("REPLACE INTO product_prices (product_name, price) VALUES (?, ?)", (name, price))
        self.conn.commit()

    def get_price(self, name):
        self.cursor.execute("SELECT price FROM product_prices WHERE product_name=?", (name,))
        return result[0] if (result := self.cursor.fetchone()) else None

    def close_connection(self):
        self.conn.close()

class SoldNumbers:
    def __init__(self, db_name):
        self.db_name = db_name
        self.connection = sqlite3.connect(db_name)
        self.cursor = self.connection.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS numbers 
                              (id INTEGER PRIMARY KEY AUTOINCREMENT,
                              user_id TEXT,
                              data TEXT,
                              number TEXT)''')
        
    def save_number(self, user_id, data, number):
        if existing_numbers := self.get_number(number):
            existing_data = existing_numbers[0][2]
            self.cursor.execute("UPDATE numbers SET data=? WHERE number=?", (data, number))
        else:
            self.cursor.execute("INSERT INTO numbers (user_id, data, number) VALUES (?,?,?)",
                                (user_id, data, number))
        self.connection.commit()

    def get_numbers(self, user_id):
        self.cursor.execute("SELECT number FROM numbers WHERE user_id=?", (user_id,))
        numbers = self.cursor.fetchall()
        numbers = [number[0] for number in numbers]
        return numbers

    def get_number(self, number):
        self.cursor.execute("SELECT * FROM numbers WHERE number=?", (number,))
        return self.cursor.fetchall()

    def count_users(self, user_id):
        self.cursor.execute("SELECT COUNT(*) FROM numbers WHERE user_id=?", (user_id,))
        return self.cursor.fetchone()[0]

class PaymentChecker:
    def __init__(self, db_name):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS payments (
                                bill_id TEXT PRIMARY KEY,
                                amount INTEGER,
                                user_id TEXT,
                                status TEXT
                            )''')
        self.conn.commit()

    def save_payment(self, bill_id, amount, user_id, status):
        self.cursor.execute('''INSERT INTO payments (bill_id, amount, user_id, status)
                               VALUES (?, ?, ?, ?)''', (bill_id, amount, user_id, status))

        self.conn.commit()

    def get_payment(self, bill_id):
        self.cursor.execute('''SELECT user_id, bill_id, amount FROM payments
                               WHERE bill_id = ?''', (bill_id,))
        return list(result) if (result := self.cursor.fetchone()) else None

    def get_status(self, bill_id):
        self.cursor.execute('''SELECT status FROM payments
                               WHERE bill_id = ?''', (bill_id,))
        return result[0] if (result := self.cursor.fetchone()) else None
    def set_status(self, bill_id, status):
        self.cursor.execute('''UPDATE payments SET status=? WHERE bill_id=?''', (status, bill_id))
    def close(self):
        self.conn.close()


class Channel:
    def __init__(self, db_name):
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.cursor.execute('''CREATE TABLE IF NOT EXISTS channels
                                (username TEXT PRIMARY KEY,
                                 saved_time TEXT)''')
        self.conn.commit()

    def save_channel(self, username):
        current_time = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.cursor.execute("INSERT INTO channels VALUES (?, ?)", (username, current_time))
        self.conn.commit()

    def get_channels(self):
        self.cursor.execute("SELECT username FROM channels")
        return [row[0] for row in self.cursor.fetchall()]

    def get_time_channel(self, username):
        self.cursor.execute("SELECT saved_time FROM channels WHERE username=?", (username,))
        return result[0] if (result := self.cursor.fetchone()) else None

    def del_channel(self, username):
        self.cursor.execute("SELECT username FROM channels WHERE username=?", (username,))
        if result := self.cursor.fetchone():
            self.cursor.execute("DELETE FROM channels WHERE username=?", (username,))
            self.conn.commit()
            return True
        else:
            return False
        

    def del_channels(self):
        self.cursor.execute("DELETE FROM channels")
        self.conn.commit()

    def __del__(self):
        self.cursor.close()
        self.conn.close()

class BanUser:
    def __init__(self, db_file):
        self.conn = sqlite3.connect(db_file)
        self.cursor = self.conn.cursor()
        self.cursor.execute("CREATE TABLE IF NOT EXISTS users (user_id TEXT)")
        self.conn.commit()
    def get_ban_users(self):
        self.cursor.execute("SELECT user_id FROM users")
        return [row[0] for row in self.cursor.fetchall()]
    def ban_user(self, user_id):
        self.cursor.execute("INSERT INTO users (user_id) VALUES (?)", (user_id,))
        self.conn.commit()

    def check_user(self, user_id):
        self.cursor.execute("SELECT COUNT(*) FROM users WHERE user_id=?", (user_id,))
        result = self.cursor.fetchone()
        return result[0] > 0

    def del_user(self, user_id):
        self.cursor.execute("DELETE FROM users WHERE user_id=?", (user_id,))
        self.conn.commit()

        return self.cursor.rowcount > 0

    def del_users(self):
        self.cursor.execute("DELETE FROM users")
        self.conn.commit()

    def get_user(self, place):
        self.cursor.execute("SELECT user_id FROM users ORDER BY ROWID ASC LIMIT 1 OFFSET ?", (place - 1,))
        result = self.cursor.fetchone()
        return result[0] if result else None

    def count_users(self):
        self.cursor.execute("SELECT COUNT(*) FROM users")
        result = self.cursor.fetchone()
        return result[0]

    def __del__(self):
        self.cursor.close()
        self.conn.close()



class FileIDSaver:
    def __init__(self, db_name):
        self.db_name = db_name
        self.conn = sqlite3.connect(db_name)
        self.cursor = self.conn.cursor()
        self.create_table()

    def create_table(self):
        table_query = '''
        CREATE TABLE IF NOT EXISTS instructions (
            name TEXT PRIMARY KEY,
            file_id TEXT NOT NULL
        );
        '''
        self.cursor.execute(table_query)
        self.conn.commit()

    def save(self, name="instruction", file_id="ababababa"):
        result = self._extracted_from_get_2(
            "SELECT name FROM instructions WHERE name = ?", name
        )
        if result is not None:
            delete_query = "DELETE FROM instructions WHERE name = ?"
            self.cursor.execute(delete_query, (name,))
            self.conn.commit()

        insert_query = "INSERT INTO instructions (name, file_id) VALUES (?, ?)"
        self.cursor.execute(insert_query, (name, file_id))
        self.conn.commit()

    def get(self, name="instruction"):
        result = self._extracted_from_get_2(
            "SELECT file_id FROM instructions WHERE name = ?", name
        )
        return result[0] if result is not None else None

    # TODO Rename this here and in `save` and `get`
    def _extracted_from_get_2(self, arg0, name):
        select_query = arg0
        self.cursor.execute(select_query, (name, ))
        return self.cursor.fetchone()